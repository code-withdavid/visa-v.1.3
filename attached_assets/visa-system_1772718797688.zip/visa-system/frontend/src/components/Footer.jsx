// components/Footer.jsx

const Footer = () => (
  <footer style={styles.footer}>
    <div style={styles.inner}>
      <p style={styles.text}>
        🛂 <strong>Online Visa Granted & Renewal Information System</strong>
      </p>
      <p style={styles.sub}>
        Final Year Computer Science Project &nbsp;|&nbsp; Built with React & Flask
      </p>
      <p style={styles.copy}>© {new Date().getFullYear()} VisaSystem. All rights reserved.</p>
    </div>
  </footer>
);

const styles = {
  footer: {
    background: '#0f2c54',
    color: 'rgba(255,255,255,0.7)',
    padding: '30px 40px',
    marginTop: 'auto',
    textAlign: 'center',
  },
  inner: { maxWidth: '800px', margin: '0 auto' },
  text: { color: 'white', fontSize: '1rem', marginBottom: '6px' },
  sub: { fontSize: '0.85rem', marginBottom: '6px' },
  copy: { fontSize: '0.8rem', opacity: 0.6 },
};

export default Footer;
