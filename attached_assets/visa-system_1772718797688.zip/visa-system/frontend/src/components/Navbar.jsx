// components/Navbar.jsx
// Top navigation bar with login/logout and navigation links

import { Link, useNavigate } from 'react-router-dom';

const Navbar = ({ user, onLogout }) => {
  const navigate = useNavigate();

  const handleLogout = () => {
    onLogout();
    navigate('/login');
  };

  return (
    <nav style={styles.nav}>
      <div style={styles.brand}>
        <Link to="/" style={styles.brandLink}>
          🛂 VisaSystem
        </Link>
      </div>

      <div style={styles.links}>
        <Link to="/" style={styles.link}>Home</Link>

        {user ? (
          <>
            <Link to="/dashboard" style={styles.link}>Dashboard</Link>
            <Link to="/apply" style={styles.link}>Apply</Link>
            <Link to="/status" style={styles.link}>My Visas</Link>
            <span style={styles.userBadge}>👤 {user.full_name}</span>
            <button onClick={handleLogout} style={styles.logoutBtn}>
              Logout
            </button>
          </>
        ) : (
          <>
            <Link to="/login" style={styles.link}>Login</Link>
            <Link to="/register" style={styles.registerBtn}>Register</Link>
          </>
        )}
      </div>
    </nav>
  );
};

const styles = {
  nav: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: '14px 40px',
    background: 'linear-gradient(135deg, #0f2c54, #1a4a8a)',
    color: 'white',
    boxShadow: '0 2px 12px rgba(0,0,0,0.3)',
    position: 'sticky',
    top: 0,
    zIndex: 100,
  },
  brand: { fontWeight: 700, fontSize: '1.4rem' },
  brandLink: { color: 'white', textDecoration: 'none' },
  links: { display: 'flex', alignItems: 'center', gap: '20px' },
  link: {
    color: 'rgba(255,255,255,0.85)',
    textDecoration: 'none',
    fontSize: '0.95rem',
    transition: 'color 0.2s',
  },
  userBadge: {
    background: 'rgba(255,255,255,0.15)',
    padding: '5px 12px',
    borderRadius: '20px',
    fontSize: '0.85rem',
  },
  logoutBtn: {
    background: 'rgba(255,80,80,0.8)',
    color: 'white',
    border: 'none',
    padding: '7px 16px',
    borderRadius: '6px',
    cursor: 'pointer',
    fontSize: '0.9rem',
    transition: 'background 0.2s',
  },
  registerBtn: {
    background: '#f0a500',
    color: '#0f2c54',
    textDecoration: 'none',
    padding: '7px 16px',
    borderRadius: '6px',
    fontWeight: 600,
    fontSize: '0.9rem',
  },
};

export default Navbar;
