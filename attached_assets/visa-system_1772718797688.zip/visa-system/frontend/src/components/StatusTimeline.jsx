// components/StatusTimeline.jsx
// Visual timeline showing visa application progress stages

const STAGES = [
  { key: 'pending', label: 'Submitted', icon: '📤' },
  { key: 'under_review', label: 'Under Review', icon: '🔍' },
  { key: 'approved', label: 'Approved', icon: '✅' },
];

const STATUS_ORDER = ['pending', 'under_review', 'approved', 'rejected'];

const StatusTimeline = ({ status }) => {
  const isRejected = status === 'rejected';

  const getStepState = (stepKey) => {
    if (isRejected) {
      if (stepKey === 'pending' || stepKey === 'under_review') return 'completed';
      if (stepKey === 'approved') return 'rejected';
    }
    const currentIndex = STATUS_ORDER.indexOf(status);
    const stepIndex = STATUS_ORDER.indexOf(stepKey);
    if (stepIndex < currentIndex) return 'completed';
    if (stepIndex === currentIndex) return 'active';
    return 'pending';
  };

  const steps = isRejected
    ? [
        { key: 'pending', label: 'Submitted', icon: '📤' },
        { key: 'under_review', label: 'Under Review', icon: '🔍' },
        { key: 'rejected_step', label: 'Rejected', icon: '❌' },
      ]
    : STAGES;

  return (
    <div style={styles.container}>
      {steps.map((step, i) => {
        const state = isRejected && step.key === 'rejected_step' ? 'rejected' : getStepState(step.key);
        return (
          <div key={step.key} style={styles.stepWrapper}>
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
              <div style={{
                ...styles.circle,
                background: state === 'completed' ? '#22c55e' :
                             state === 'active' ? '#3b82f6' :
                             state === 'rejected' ? '#ef4444' : '#d1d5db',
                color: state === 'pending' ? '#9ca3af' : 'white',
                boxShadow: state === 'active' ? '0 0 0 4px rgba(59,130,246,0.25)' : 'none',
              }}>
                {step.icon}
              </div>
              <span style={{
                ...styles.label,
                color: state === 'pending' ? '#9ca3af' :
                       state === 'rejected' ? '#ef4444' : '#1f2937',
                fontWeight: state === 'active' ? 700 : 400,
              }}>
                {step.label}
              </span>
            </div>
            {i < steps.length - 1 && (
              <div style={{
                ...styles.line,
                background: getStepState(steps[i + 1]?.key) === 'pending' && !isRejected
                  ? '#d1d5db' : '#22c55e',
              }} />
            )}
          </div>
        );
      })}
    </div>
  );
};

const styles = {
  container: {
    display: 'flex',
    alignItems: 'flex-start',
    justifyContent: 'center',
    padding: '20px 0',
    gap: 0,
  },
  stepWrapper: {
    display: 'flex',
    alignItems: 'center',
    gap: 0,
  },
  circle: {
    width: '48px',
    height: '48px',
    borderRadius: '50%',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    fontSize: '1.2rem',
    transition: 'all 0.3s ease',
  },
  label: {
    fontSize: '0.78rem',
    marginTop: '8px',
    textAlign: 'center',
    maxWidth: '70px',
  },
  line: {
    width: '80px',
    height: '3px',
    borderRadius: '2px',
    marginBottom: '20px',
    transition: 'background 0.3s',
  },
};

export default StatusTimeline;
