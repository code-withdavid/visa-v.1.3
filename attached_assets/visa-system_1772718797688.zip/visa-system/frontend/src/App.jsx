// App.jsx
// Root component - sets up routing and global authentication state

import { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';

import Navbar from './components/Navbar';
import Footer from './components/Footer';

import Home from './pages/Home';
import Login from './pages/Login';
import Register from './pages/Register';
import Dashboard from './pages/Dashboard';
import VisaForm from './pages/VisaForm';
import VisaStatus from './pages/VisaStatus';
import Renewal from './pages/Renewal';

// Protected route: redirects to /login if user is not authenticated
const PrivateRoute = ({ user, children }) => {
  return user ? children : <Navigate to="/login" replace />;
};

function App() {
  const [user, setUser] = useState(null);

  // On app load, restore user from localStorage if token exists
  useEffect(() => {
    const savedUser = localStorage.getItem('user');
    const token = localStorage.getItem('token');
    if (savedUser && token) {
      setUser(JSON.parse(savedUser));
    }
  }, []);

  const handleLogin = (userData) => {
    setUser(userData);
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    setUser(null);
  };

  return (
    <Router>
      <div style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column' }}>
        <Navbar user={user} onLogout={handleLogout} />

        <main style={{ flex: 1 }}>
          <Routes>
            {/* Public routes */}
            <Route path="/" element={<Home />} />
            <Route path="/login" element={<Login onLogin={handleLogin} />} />
            <Route path="/register" element={<Register />} />

            {/* Protected routes (require login) */}
            <Route path="/dashboard" element={
              <PrivateRoute user={user}>
                <Dashboard user={user} />
              </PrivateRoute>
            } />
            <Route path="/apply" element={
              <PrivateRoute user={user}>
                <VisaForm />
              </PrivateRoute>
            } />
            <Route path="/status" element={
              <PrivateRoute user={user}>
                <VisaStatus />
              </PrivateRoute>
            } />
            <Route path="/renew" element={
              <PrivateRoute user={user}>
                <Renewal />
              </PrivateRoute>
            } />

            {/* Catch-all: redirect to home */}
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </main>

        <Footer />
      </div>
    </Router>
  );
}

export default App;
