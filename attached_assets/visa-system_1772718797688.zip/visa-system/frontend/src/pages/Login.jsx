// pages/Login.jsx
import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';

const API = 'http://localhost:5000/api';

const Login = ({ onLogin }) => {
  const [form, setForm] = useState({ email: '', password: '' });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const res = await fetch(`${API}/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      });
      const data = await res.json();

      if (data.success) {
        // Save token and user info
        localStorage.setItem('token', data.access_token);
        localStorage.setItem('user', JSON.stringify(data.user));
        onLogin(data.user);
        navigate('/dashboard');
      } else {
        setError(data.message || 'Login failed');
      }
    } catch (err) {
      setError('Cannot connect to server. Make sure the backend is running.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={styles.page}>
      <div style={styles.card}>
        <div style={styles.header}>
          <h2 style={styles.title}>🛂 Welcome Back</h2>
          <p style={styles.subtitle}>Sign in to your account</p>
        </div>

        {error && <div style={styles.error}>⚠️ {error}</div>}

        <form onSubmit={handleSubmit}>
          <div style={styles.field}>
            <label style={styles.label}>Email Address</label>
            <input
              type="email"
              name="email"
              value={form.email}
              onChange={handleChange}
              placeholder="your@email.com"
              required
              style={styles.input}
            />
          </div>

          <div style={styles.field}>
            <label style={styles.label}>Password</label>
            <input
              type="password"
              name="password"
              value={form.password}
              onChange={handleChange}
              placeholder="••••••••"
              required
              style={styles.input}
            />
          </div>

          <button type="submit" disabled={loading} style={styles.btn}>
            {loading ? 'Signing in...' : 'Sign In →'}
          </button>
        </form>

        <p style={styles.switch}>
          Don't have an account?{' '}
          <Link to="/register" style={styles.switchLink}>Register here</Link>
        </p>
      </div>
    </div>
  );
};

const styles = {
  page: {
    minHeight: '80vh', display: 'flex',
    alignItems: 'center', justifyContent: 'center',
    background: '#f0f4ff', padding: '40px 20px',
  },
  card: {
    background: 'white', borderRadius: '16px', padding: '48px',
    width: '100%', maxWidth: '440px',
    boxShadow: '0 4px 30px rgba(0,0,0,0.1)',
  },
  header: { textAlign: 'center', marginBottom: '32px' },
  title: { fontSize: '1.8rem', fontWeight: 800, color: '#0f2c54', marginBottom: '8px' },
  subtitle: { color: '#666', fontSize: '0.95rem' },
  error: {
    background: '#fef2f2', border: '1px solid #fecaca',
    color: '#dc2626', padding: '12px 16px', borderRadius: '8px',
    marginBottom: '20px', fontSize: '0.9rem',
  },
  field: { marginBottom: '20px' },
  label: { display: 'block', fontSize: '0.9rem', fontWeight: 600, color: '#374151', marginBottom: '6px' },
  input: {
    width: '100%', padding: '12px 14px', borderRadius: '8px',
    border: '2px solid #e5e7eb', fontSize: '0.95rem', outline: 'none',
    boxSizing: 'border-box', transition: 'border-color 0.2s',
  },
  btn: {
    width: '100%', padding: '14px', background: '#0f2c54',
    color: 'white', border: 'none', borderRadius: '8px',
    fontSize: '1rem', fontWeight: 700, cursor: 'pointer',
    marginTop: '8px', transition: 'background 0.2s',
  },
  switch: { textAlign: 'center', marginTop: '24px', color: '#666', fontSize: '0.9rem' },
  switchLink: { color: '#1a4a8a', fontWeight: 600, textDecoration: 'none' },
};

export default Login;
