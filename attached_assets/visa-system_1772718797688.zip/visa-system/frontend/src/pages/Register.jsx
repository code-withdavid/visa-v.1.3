// pages/Register.jsx
import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';

const API = 'http://localhost:5000/api';

const Register = () => {
  const [form, setForm] = useState({
    full_name: '', email: '', password: '', confirm_password: '',
    phone: '', nationality: '', date_of_birth: '',
  });
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');

    if (form.password !== form.confirm_password) {
      return setError('Passwords do not match');
    }
    if (form.password.length < 6) {
      return setError('Password must be at least 6 characters');
    }

    setLoading(true);

    try {
      const res = await fetch(`${API}/register`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          full_name: form.full_name,
          email: form.email,
          password: form.password,
          phone: form.phone,
          nationality: form.nationality,
          date_of_birth: form.date_of_birth,
        }),
      });
      const data = await res.json();

      if (data.success) {
        setSuccess('Account created! Redirecting to login...');
        setTimeout(() => navigate('/login'), 2000);
      } else {
        setError(data.message || 'Registration failed');
      }
    } catch (err) {
      setError('Cannot connect to server. Make sure the backend is running.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={styles.page}>
      <div style={styles.card}>
        <div style={styles.header}>
          <h2 style={styles.title}>🛂 Create Account</h2>
          <p style={styles.subtitle}>Join the Visa Information System</p>
        </div>

        {error && <div style={styles.error}>⚠️ {error}</div>}
        {success && <div style={styles.success}>✅ {success}</div>}

        <form onSubmit={handleSubmit}>
          <div style={styles.grid}>
            <Field label="Full Name *" name="full_name" type="text" placeholder="John Doe" form={form} onChange={handleChange} required />
            <Field label="Email Address *" name="email" type="email" placeholder="john@email.com" form={form} onChange={handleChange} required />
            <Field label="Password *" name="password" type="password" placeholder="Min 6 characters" form={form} onChange={handleChange} required />
            <Field label="Confirm Password *" name="confirm_password" type="password" placeholder="Repeat password" form={form} onChange={handleChange} required />
            <Field label="Phone Number" name="phone" type="tel" placeholder="+1 234 567 8900" form={form} onChange={handleChange} />
            <Field label="Nationality" name="nationality" type="text" placeholder="e.g. American" form={form} onChange={handleChange} />
          </div>

          <div style={styles.field}>
            <label style={styles.label}>Date of Birth</label>
            <input
              type="date"
              name="date_of_birth"
              value={form.date_of_birth}
              onChange={handleChange}
              style={styles.input}
            />
          </div>

          <button type="submit" disabled={loading} style={styles.btn}>
            {loading ? 'Creating Account...' : 'Create Account →'}
          </button>
        </form>

        <p style={styles.switch}>
          Already have an account?{' '}
          <Link to="/login" style={styles.switchLink}>Sign in here</Link>
        </p>
      </div>
    </div>
  );
};

// Small reusable field component
const Field = ({ label, name, type, placeholder, form, onChange, required }) => (
  <div style={{ marginBottom: '16px' }}>
    <label style={{ display: 'block', fontSize: '0.88rem', fontWeight: 600, color: '#374151', marginBottom: '5px' }}>
      {label}
    </label>
    <input
      type={type}
      name={name}
      value={form[name]}
      onChange={onChange}
      placeholder={placeholder}
      required={required}
      style={{
        width: '100%', padding: '11px 13px', borderRadius: '7px',
        border: '2px solid #e5e7eb', fontSize: '0.9rem', outline: 'none', boxSizing: 'border-box',
      }}
    />
  </div>
);

const styles = {
  page: {
    minHeight: '80vh', display: 'flex', alignItems: 'center', justifyContent: 'center',
    background: '#f0f4ff', padding: '40px 20px',
  },
  card: {
    background: 'white', borderRadius: '16px', padding: '48px',
    width: '100%', maxWidth: '620px', boxShadow: '0 4px 30px rgba(0,0,0,0.1)',
  },
  header: { textAlign: 'center', marginBottom: '28px' },
  title: { fontSize: '1.8rem', fontWeight: 800, color: '#0f2c54', marginBottom: '8px' },
  subtitle: { color: '#666', fontSize: '0.95rem' },
  error: {
    background: '#fef2f2', border: '1px solid #fecaca',
    color: '#dc2626', padding: '12px 16px', borderRadius: '8px',
    marginBottom: '20px', fontSize: '0.9rem',
  },
  success: {
    background: '#f0fdf4', border: '1px solid #bbf7d0',
    color: '#15803d', padding: '12px 16px', borderRadius: '8px',
    marginBottom: '20px', fontSize: '0.9rem',
  },
  grid: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0 16px' },
  field: { marginBottom: '16px' },
  label: { display: 'block', fontSize: '0.88rem', fontWeight: 600, color: '#374151', marginBottom: '5px' },
  input: {
    width: '100%', padding: '11px 13px', borderRadius: '7px',
    border: '2px solid #e5e7eb', fontSize: '0.9rem', outline: 'none', boxSizing: 'border-box',
  },
  btn: {
    width: '100%', padding: '14px', background: '#0f2c54', color: 'white',
    border: 'none', borderRadius: '8px', fontSize: '1rem', fontWeight: 700,
    cursor: 'pointer', marginTop: '8px',
  },
  switch: { textAlign: 'center', marginTop: '20px', color: '#666', fontSize: '0.9rem' },
  switchLink: { color: '#1a4a8a', fontWeight: 600, textDecoration: 'none' },
};

export default Register;
