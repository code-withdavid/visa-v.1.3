// pages/Dashboard.jsx
import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';

const API = 'http://localhost:5000/api';

const statusColors = {
  pending: { bg: '#fef9c3', color: '#a16207', label: '🕐 Pending' },
  under_review: { bg: '#dbeafe', color: '#1d4ed8', label: '🔍 Under Review' },
  approved: { bg: '#dcfce7', color: '#15803d', label: '✅ Approved' },
  rejected: { bg: '#fee2e2', color: '#dc2626', label: '❌ Rejected' },
  expired: { bg: '#f3f4f6', color: '#6b7280', label: '⏰ Expired' },
  renewal_pending: { bg: '#fef3c7', color: '#b45309', label: '🔄 Renewal Pending' },
};

const Dashboard = ({ user }) => {
  const [visas, setVisas] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    fetchVisas();
  }, []);

  const fetchVisas = async () => {
    try {
      const token = localStorage.getItem('token');
      const res = await fetch(`${API}/visa-status`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = await res.json();
      if (data.success) {
        setVisas(data.visas);
      } else {
        setError(data.message);
      }
    } catch {
      setError('Failed to load your applications.');
    } finally {
      setLoading(false);
    }
  };

  const stats = {
    total: visas.length,
    approved: visas.filter(v => v.status === 'approved').length,
    pending: visas.filter(v => ['pending', 'under_review'].includes(v.status)).length,
    rejected: visas.filter(v => v.status === 'rejected').length,
  };

  return (
    <div style={styles.page}>
      {/* Header */}
      <div style={styles.header}>
        <div>
          <h1 style={styles.title}>Welcome back, {user?.full_name?.split(' ')[0]}! 👋</h1>
          <p style={styles.subtitle}>Here's an overview of your visa applications</p>
        </div>
        <Link to="/apply" style={styles.applyBtn}>+ New Application</Link>
      </div>

      {/* Stats Cards */}
      <div style={styles.statsGrid}>
        {[
          { label: 'Total Applications', value: stats.total, color: '#0f2c54', icon: '📋' },
          { label: 'Approved', value: stats.approved, color: '#15803d', icon: '✅' },
          { label: 'Pending Review', value: stats.pending, color: '#1d4ed8', icon: '🔍' },
          { label: 'Rejected', value: stats.rejected, color: '#dc2626', icon: '❌' },
        ].map(stat => (
          <div key={stat.label} style={{ ...styles.statCard, borderTop: `4px solid ${stat.color}` }}>
            <span style={styles.statIcon}>{stat.icon}</span>
            <span style={{ ...styles.statValue, color: stat.color }}>{stat.value}</span>
            <span style={styles.statLabel}>{stat.label}</span>
          </div>
        ))}
      </div>

      {/* Quick Actions */}
      <div style={styles.actionsRow}>
        <h2 style={styles.sectionTitle}>Quick Actions</h2>
        <div style={styles.actions}>
          <Link to="/apply" style={styles.actionCard}>
            <span style={styles.actionIcon}>🌍</span>
            <span>Apply for Visa</span>
          </Link>
          <Link to="/status" style={styles.actionCard}>
            <span style={styles.actionIcon}>🔍</span>
            <span>Track Status</span>
          </Link>
          <Link to="/renew" style={styles.actionCard}>
            <span style={styles.actionIcon}>🔄</span>
            <span>Renew Visa</span>
          </Link>
        </div>
      </div>

      {/* Recent Applications */}
      <div style={styles.tableSection}>
        <h2 style={styles.sectionTitle}>Recent Applications</h2>

        {loading && <p style={styles.loadingMsg}>Loading your applications...</p>}
        {error && <div style={styles.errorBox}>⚠️ {error}</div>}

        {!loading && visas.length === 0 && (
          <div style={styles.emptyState}>
            <p style={{ fontSize: '3rem' }}>📭</p>
            <p>You haven't submitted any visa applications yet.</p>
            <Link to="/apply" style={styles.applyBtn}>Apply Now</Link>
          </div>
        )}

        {!loading && visas.length > 0 && (
          <div style={styles.tableWrapper}>
            <table style={styles.table}>
              <thead>
                <tr style={styles.tableHead}>
                  <th style={styles.th}>Application #</th>
                  <th style={styles.th}>Visa Type</th>
                  <th style={styles.th}>Destination</th>
                  <th style={styles.th}>Travel Date</th>
                  <th style={styles.th}>Status</th>
                  <th style={styles.th}>Action</th>
                </tr>
              </thead>
              <tbody>
                {visas.slice(0, 5).map(visa => {
                  const s = statusColors[visa.status] || statusColors.pending;
                  return (
                    <tr key={visa.id} style={styles.tableRow}>
                      <td style={styles.td}><code style={styles.appNum}>{visa.application_number}</code></td>
                      <td style={styles.td}>{visa.visa_type?.toUpperCase()}</td>
                      <td style={styles.td}>{visa.destination_country}</td>
                      <td style={styles.td}>{visa.travel_date?.split('T')[0] || '—'}</td>
                      <td style={styles.td}>
                        <span style={{ ...styles.badge, background: s.bg, color: s.color }}>
                          {s.label}
                        </span>
                      </td>
                      <td style={styles.td}>
                        <Link to={`/status?app=${visa.application_number}`} style={styles.viewLink}>View →</Link>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};

const styles = {
  page: { padding: '40px', maxWidth: '1100px', margin: '0 auto' },
  header: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '32px', flexWrap: 'wrap', gap: '16px' },
  title: { fontSize: '1.8rem', fontWeight: 800, color: '#0f2c54' },
  subtitle: { color: '#666', marginTop: '4px' },
  applyBtn: {
    background: '#0f2c54', color: 'white', padding: '12px 24px',
    borderRadius: '8px', textDecoration: 'none', fontWeight: 600,
  },
  statsGrid: { display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: '20px', marginBottom: '40px' },
  statCard: {
    background: 'white', borderRadius: '12px', padding: '24px',
    display: 'flex', flexDirection: 'column', alignItems: 'center',
    boxShadow: '0 2px 10px rgba(0,0,0,0.06)', textAlign: 'center', gap: '6px',
  },
  statIcon: { fontSize: '1.8rem' },
  statValue: { fontSize: '2.4rem', fontWeight: 800 },
  statLabel: { fontSize: '0.85rem', color: '#666', fontWeight: 500 },
  actionsRow: { marginBottom: '40px' },
  sectionTitle: { fontSize: '1.2rem', fontWeight: 700, color: '#0f2c54', marginBottom: '16px' },
  actions: { display: 'flex', gap: '16px', flexWrap: 'wrap' },
  actionCard: {
    background: 'white', border: '2px solid #e5e7eb',
    padding: '20px 32px', borderRadius: '12px', textDecoration: 'none',
    color: '#0f2c54', fontWeight: 600, display: 'flex', flexDirection: 'column',
    alignItems: 'center', gap: '8px', transition: 'border-color 0.2s',
  },
  actionIcon: { fontSize: '1.8rem' },
  tableSection: {},
  tableWrapper: { overflowX: 'auto' },
  table: { width: '100%', borderCollapse: 'collapse', background: 'white', borderRadius: '12px', overflow: 'hidden', boxShadow: '0 2px 10px rgba(0,0,0,0.06)' },
  tableHead: { background: '#0f2c54', color: 'white' },
  th: { padding: '14px 16px', textAlign: 'left', fontSize: '0.85rem', fontWeight: 600 },
  tableRow: { borderBottom: '1px solid #f3f4f6' },
  td: { padding: '14px 16px', fontSize: '0.9rem', color: '#374151' },
  appNum: { background: '#f3f4f6', padding: '3px 8px', borderRadius: '4px', fontSize: '0.8rem' },
  badge: { padding: '4px 12px', borderRadius: '20px', fontSize: '0.8rem', fontWeight: 600, whiteSpace: 'nowrap' },
  viewLink: { color: '#1a4a8a', fontWeight: 600, textDecoration: 'none', fontSize: '0.9rem' },
  loadingMsg: { textAlign: 'center', color: '#666', padding: '40px' },
  errorBox: { background: '#fef2f2', color: '#dc2626', padding: '16px', borderRadius: '8px', border: '1px solid #fecaca' },
  emptyState: { textAlign: 'center', padding: '60px', color: '#666', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '16px' },
};

export default Dashboard;
