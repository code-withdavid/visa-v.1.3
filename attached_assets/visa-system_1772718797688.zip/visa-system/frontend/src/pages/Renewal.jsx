// pages/Renewal.jsx
import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

const API = 'http://localhost:5000/api';

const Renewal = () => {
  const navigate = useNavigate();
  const [approvedVisas, setApprovedVisas] = useState([]);
  const [selectedVisa, setSelectedVisa] = useState('');
  const [form, setForm] = useState({
    visa_type: '', destination_country: '',
    travel_date: '', return_date: '',
    duration_of_stay: '', purpose_of_visit: '',
  });
  const [loading, setLoading] = useState(false);
  const [fetching, setFetching] = useState(true);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(null);

  useEffect(() => {
    const fetchVisas = async () => {
      try {
        const token = localStorage.getItem('token');
        const res = await fetch(`${API}/visa-status`, {
          headers: { Authorization: `Bearer ${token}` },
        });
        const data = await res.json();
        if (data.success) {
          const eligible = data.visas.filter(v => ['approved', 'expired'].includes(v.status));
          setApprovedVisas(eligible);
        }
      } finally {
        setFetching(false);
      }
    };
    fetchVisas();
  }, []);

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSelectVisa = (e) => {
    const visaId = e.target.value;
    setSelectedVisa(visaId);
    const visa = approvedVisas.find(v => v.id === parseInt(visaId));
    if (visa) {
      setForm(prev => ({
        ...prev,
        visa_type: visa.visa_type,
        destination_country: visa.destination_country,
      }));
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!selectedVisa) return setError('Please select a visa to renew');
    setError('');
    setLoading(true);

    try {
      const token = localStorage.getItem('token');
      const res = await fetch(`${API}/renew-visa`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({
          previous_visa_id: parseInt(selectedVisa),
          ...form,
          duration_of_stay: parseInt(form.duration_of_stay, 10),
        }),
      });
      const data = await res.json();

      if (data.success) {
        setSuccess(data);
      } else {
        setError(data.message || 'Renewal failed');
      }
    } catch {
      setError('Cannot connect to server. Make sure the backend is running.');
    } finally {
      setLoading(false);
    }
  };

  if (success) {
    return (
      <div style={styles.page}>
        <div style={styles.successCard}>
          <div style={{ fontSize: '3.5rem' }}>🔄</div>
          <h2 style={styles.successTitle}>Renewal Submitted!</h2>
          <p style={styles.successMsg}>Your visa renewal application has been received.</p>
          <div style={styles.appBox}>
            <span style={{ fontSize: '0.8rem', color: '#666' }}>Renewal Application Number</span>
            <code style={styles.appNum}>{success.application_number}</code>
          </div>
          <div style={styles.btnRow}>
            <button onClick={() => navigate('/dashboard')} style={styles.btn}>Dashboard</button>
            <button onClick={() => navigate('/status')} style={styles.outlineBtn}>Track Status</button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div style={styles.page}>
      <div style={styles.card}>
        <h2 style={styles.cardTitle}>🔄 Visa Renewal Request</h2>
        <p style={styles.cardSubtitle}>Submit a renewal for an existing approved or expired visa</p>

        {error && <div style={styles.error}>⚠️ {error}</div>}

        {fetching ? (
          <p style={{ color: '#666' }}>Loading your visas...</p>
        ) : approvedVisas.length === 0 ? (
          <div style={styles.noVisas}>
            <p style={{ fontSize: '2.5rem' }}>📋</p>
            <p>No approved or expired visas found for renewal.</p>
            <p style={{ fontSize: '0.9rem', color: '#9ca3af' }}>
              You can only renew visas that have been approved or have expired.
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit}>
            <div style={styles.field}>
              <label style={styles.label}>Select Visa to Renew *</label>
              <select value={selectedVisa} onChange={handleSelectVisa} required style={styles.input}>
                <option value="">— Select a visa —</option>
                {approvedVisas.map(v => (
                  <option key={v.id} value={v.id}>
                    {v.application_number} — {v.visa_type?.toUpperCase()} to {v.destination_country} ({v.status})
                  </option>
                ))}
              </select>
            </div>

            <div style={styles.divider} />
            <h3 style={styles.subTitle}>New Travel Details</h3>

            <div style={styles.grid}>
              <div style={styles.field}>
                <label style={styles.label}>Visa Type *</label>
                <select name="visa_type" value={form.visa_type} onChange={handleChange} required style={styles.input}>
                  <option value="">Select type</option>
                  {['tourist', 'student', 'work', 'business', 'transit', 'medical'].map(t => (
                    <option key={t} value={t}>{t.charAt(0).toUpperCase() + t.slice(1)}</option>
                  ))}
                </select>
              </div>
              <div style={styles.field}>
                <label style={styles.label}>Destination Country *</label>
                <input type="text" name="destination_country" value={form.destination_country}
                  onChange={handleChange} required placeholder="e.g. France" style={styles.input} />
              </div>
              <div style={styles.field}>
                <label style={styles.label}>Travel Date *</label>
                <input type="date" name="travel_date" value={form.travel_date}
                  onChange={handleChange} required style={styles.input} />
              </div>
              <div style={styles.field}>
                <label style={styles.label}>Return Date *</label>
                <input type="date" name="return_date" value={form.return_date}
                  onChange={handleChange} required style={styles.input} />
              </div>
            </div>

            <div style={styles.field}>
              <label style={styles.label}>Duration of Stay (days) *</label>
              <input type="number" name="duration_of_stay" value={form.duration_of_stay}
                onChange={handleChange} required min="1" placeholder="e.g. 30" style={styles.input} />
            </div>

            <div style={styles.field}>
              <label style={styles.label}>Purpose of Visit</label>
              <textarea name="purpose_of_visit" value={form.purpose_of_visit}
                onChange={handleChange} rows={3}
                placeholder="Reason for renewal visit..."
                style={{ ...styles.input, resize: 'vertical' }} />
            </div>

            <button type="submit" disabled={loading} style={styles.btn}>
              {loading ? 'Submitting...' : '🔄 Submit Renewal Application'}
            </button>
          </form>
        )}
      </div>
    </div>
  );
};

const styles = {
  page: { padding: '40px 20px', background: '#f0f4ff', minHeight: '80vh', display: 'flex', justifyContent: 'center' },
  card: { background: 'white', borderRadius: '16px', padding: '40px', width: '100%', maxWidth: '600px', boxShadow: '0 4px 24px rgba(0,0,0,0.1)', height: 'fit-content' },
  cardTitle: { fontSize: '1.6rem', fontWeight: 800, color: '#0f2c54', marginBottom: '6px' },
  cardSubtitle: { color: '#666', marginBottom: '28px', fontSize: '0.95rem' },
  error: { background: '#fef2f2', border: '1px solid #fecaca', color: '#dc2626', padding: '12px 16px', borderRadius: '8px', marginBottom: '20px', fontSize: '0.9rem' },
  field: { marginBottom: '20px' },
  label: { display: 'block', fontSize: '0.9rem', fontWeight: 600, color: '#374151', marginBottom: '6px' },
  input: { width: '100%', padding: '11px 13px', borderRadius: '7px', border: '2px solid #e5e7eb', fontSize: '0.9rem', outline: 'none', boxSizing: 'border-box' },
  grid: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' },
  divider: { borderTop: '1px solid #f3f4f6', margin: '24px 0' },
  subTitle: { fontWeight: 700, color: '#374151', marginBottom: '20px', fontSize: '1rem' },
  btn: { width: '100%', padding: '14px', background: '#0f2c54', color: 'white', border: 'none', borderRadius: '8px', fontSize: '1rem', fontWeight: 700, cursor: 'pointer' },
  noVisas: { textAlign: 'center', padding: '40px 20px', color: '#666', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '12px' },
  successCard: { background: 'white', borderRadius: '16px', padding: '60px 48px', width: '100%', maxWidth: '460px', textAlign: 'center', boxShadow: '0 4px 24px rgba(0,0,0,0.1)', height: 'fit-content', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '16px' },
  successTitle: { fontSize: '1.8rem', fontWeight: 800, color: '#0f2c54' },
  successMsg: { color: '#666' },
  appBox: { background: '#f0f4ff', border: '1px solid #dbeafe', borderRadius: '10px', padding: '20px', width: '100%', display: 'flex', flexDirection: 'column', gap: '6px', alignItems: 'center' },
  appNum: { fontSize: '1.1rem', fontWeight: 700, color: '#0f2c54' },
  btnRow: { display: 'flex', gap: '12px' },
  outlineBtn: { padding: '12px 24px', background: 'white', color: '#0f2c54', border: '2px solid #0f2c54', borderRadius: '8px', fontWeight: 600, cursor: 'pointer' },
};

export default Renewal;
