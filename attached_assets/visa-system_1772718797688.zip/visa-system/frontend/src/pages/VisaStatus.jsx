// pages/VisaStatus.jsx
import { useState, useEffect } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import StatusTimeline from '../components/StatusTimeline';

const API = 'http://localhost:5000/api';

const statusInfo = {
  pending: { label: 'Pending Review', color: '#a16207', bg: '#fef9c3', desc: 'Your application has been received and is awaiting review.' },
  under_review: { label: 'Under Review', color: '#1d4ed8', bg: '#dbeafe', desc: 'An officer is currently reviewing your application.' },
  approved: { label: 'Approved', color: '#15803d', bg: '#dcfce7', desc: 'Congratulations! Your visa has been approved.' },
  rejected: { label: 'Rejected', color: '#dc2626', bg: '#fee2e2', desc: 'Your application has been rejected. See admin notes for details.' },
  expired: { label: 'Expired', color: '#6b7280', bg: '#f3f4f6', desc: 'This visa has expired. Consider applying for a renewal.' },
};

const VisaStatus = () => {
  const [searchParams] = useSearchParams();
  const [visas, setVisas] = useState([]);
  const [selectedVisa, setSelectedVisa] = useState(null);
  const [loading, setLoading] = useState(true);
  const [searchNum, setSearchNum] = useState(searchParams.get('app') || '');

  useEffect(() => {
    fetchAllVisas();
  }, []);

  useEffect(() => {
    if (searchParams.get('app') && visas.length > 0) {
      const found = visas.find(v => v.application_number === searchParams.get('app'));
      if (found) setSelectedVisa(found);
    }
  }, [visas, searchParams]);

  const fetchAllVisas = async () => {
    try {
      const token = localStorage.getItem('token');
      const res = await fetch(`${API}/visa-status`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = await res.json();
      if (data.success) setVisas(data.visas);
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = async (e) => {
    e.preventDefault();
    if (!searchNum.trim()) return;
    const found = visas.find(v => v.application_number === searchNum.trim().toUpperCase());
    if (found) {
      setSelectedVisa(found);
    } else {
      alert('Application not found');
    }
  };

  const info = selectedVisa ? (statusInfo[selectedVisa.status] || statusInfo.pending) : null;

  return (
    <div style={styles.page}>
      <div style={styles.header}>
        <h1 style={styles.title}>🔍 Visa Status Tracker</h1>
        <p style={styles.subtitle}>View and track all your visa applications</p>
      </div>

      {/* Search bar */}
      <form onSubmit={handleSearch} style={styles.searchForm}>
        <input
          type="text"
          value={searchNum}
          onChange={(e) => setSearchNum(e.target.value)}
          placeholder="Enter application number (e.g. VIS-2024-ABCD1234)"
          style={styles.searchInput}
        />
        <button type="submit" style={styles.searchBtn}>Search</button>
      </form>

      <div style={styles.layout}>
        {/* Left: Visa List */}
        <div style={styles.list}>
          <h3 style={styles.listTitle}>Your Applications ({visas.length})</h3>
          {loading && <p style={styles.loadMsg}>Loading...</p>}
          {!loading && visas.length === 0 && (
            <div style={styles.emptyList}>
              <p>No applications yet</p>
              <Link to="/apply" style={styles.applyLink}>Apply Now →</Link>
            </div>
          )}
          {visas.map(visa => {
            const si = statusInfo[visa.status] || statusInfo.pending;
            return (
              <div
                key={visa.id}
                onClick={() => setSelectedVisa(visa)}
                style={{
                  ...styles.listItem,
                  border: selectedVisa?.id === visa.id ? '2px solid #1a4a8a' : '2px solid #f3f4f6',
                }}
              >
                <div>
                  <p style={styles.listAppNum}>{visa.application_number}</p>
                  <p style={styles.listType}>{visa.visa_type?.toUpperCase()} — {visa.destination_country}</p>
                </div>
                <span style={{ ...styles.badge, background: si.bg, color: si.color }}>{si.label}</span>
              </div>
            );
          })}
        </div>

        {/* Right: Detail Panel */}
        <div style={styles.detail}>
          {!selectedVisa ? (
            <div style={styles.noSelection}>
              <span style={{ fontSize: '3rem' }}>📋</span>
              <p>Select an application to view details</p>
            </div>
          ) : (
            <>
              <div style={styles.detailHeader}>
                <div>
                  <code style={styles.detailAppNum}>{selectedVisa.application_number}</code>
                  <h3 style={styles.detailTitle}>
                    {selectedVisa.visa_type?.toUpperCase()} VISA — {selectedVisa.destination_country}
                  </h3>
                </div>
                <span style={{ ...styles.bigBadge, background: info.bg, color: info.color }}>
                  {info.label}
                </span>
              </div>

              <p style={styles.statusDesc}>{info.desc}</p>

              {/* Timeline */}
              <StatusTimeline status={selectedVisa.status} />

              {/* Details Grid */}
              <div style={styles.detailGrid}>
                <DetailRow label="Travel Date" value={selectedVisa.travel_date?.split('T')[0] || '—'} />
                <DetailRow label="Return Date" value={selectedVisa.return_date?.split('T')[0] || '—'} />
                <DetailRow label="Duration" value={`${selectedVisa.duration_of_stay} days`} />
                <DetailRow label="Application Type" value={selectedVisa.application_type} />
                <DetailRow label="Submitted On" value={selectedVisa.submitted_at?.split('T')[0] || '—'} />
                {selectedVisa.expiry_date && <DetailRow label="Visa Expiry" value={selectedVisa.expiry_date?.split('T')[0]} />}
              </div>

              {selectedVisa.admin_notes && (
                <div style={styles.notesBox}>
                  <h4 style={styles.notesTitle}>📝 Admin Notes</h4>
                  <p style={styles.notesText}>{selectedVisa.admin_notes}</p>
                </div>
              )}

              {selectedVisa.status === 'approved' && (
                <Link to="/renew" style={styles.renewBtn}>🔄 Request Renewal</Link>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
};

const DetailRow = ({ label, value }) => (
  <div style={{ padding: '10px 0', borderBottom: '1px solid #f3f4f6' }}>
    <span style={{ fontSize: '0.82rem', color: '#9ca3af', display: 'block' }}>{label}</span>
    <span style={{ fontWeight: 600, color: '#1f2937', fontSize: '0.95rem' }}>{value}</span>
  </div>
);

const styles = {
  page: { padding: '40px', maxWidth: '1100px', margin: '0 auto' },
  header: { marginBottom: '28px' },
  title: { fontSize: '1.8rem', fontWeight: 800, color: '#0f2c54' },
  subtitle: { color: '#666', marginTop: '6px' },
  searchForm: { display: 'flex', gap: '12px', marginBottom: '32px' },
  searchInput: {
    flex: 1, padding: '12px 16px', borderRadius: '8px',
    border: '2px solid #e5e7eb', fontSize: '0.95rem', outline: 'none',
  },
  searchBtn: {
    padding: '12px 28px', background: '#0f2c54', color: 'white',
    border: 'none', borderRadius: '8px', fontWeight: 600, cursor: 'pointer',
  },
  layout: { display: 'grid', gridTemplateColumns: '320px 1fr', gap: '24px' },
  list: { display: 'flex', flexDirection: 'column', gap: '12px' },
  listTitle: { fontSize: '0.95rem', fontWeight: 700, color: '#374151', marginBottom: '8px' },
  loadMsg: { color: '#666', fontSize: '0.9rem' },
  emptyList: { textAlign: 'center', padding: '40px 20px', color: '#9ca3af' },
  applyLink: { color: '#1a4a8a', fontWeight: 600, textDecoration: 'none' },
  listItem: {
    background: 'white', borderRadius: '10px', padding: '14px 16px',
    cursor: 'pointer', display: 'flex', justifyContent: 'space-between', alignItems: 'center',
    gap: '8px', transition: 'border-color 0.2s',
  },
  listAppNum: { fontSize: '0.78rem', fontFamily: 'monospace', color: '#6b7280', marginBottom: '2px' },
  listType: { fontSize: '0.9rem', fontWeight: 600, color: '#1f2937' },
  badge: { padding: '4px 10px', borderRadius: '20px', fontSize: '0.75rem', fontWeight: 600, whiteSpace: 'nowrap' },
  detail: { background: 'white', borderRadius: '16px', padding: '32px', boxShadow: '0 2px 12px rgba(0,0,0,0.07)', minHeight: '400px' },
  noSelection: { display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', height: '100%', color: '#9ca3af', gap: '16px', textAlign: 'center' },
  detailHeader: { display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '16px' },
  detailAppNum: { fontSize: '0.8rem', color: '#6b7280', display: 'block', marginBottom: '4px' },
  detailTitle: { fontSize: '1.2rem', fontWeight: 800, color: '#0f2c54' },
  bigBadge: { padding: '8px 18px', borderRadius: '20px', fontSize: '0.9rem', fontWeight: 700, whiteSpace: 'nowrap' },
  statusDesc: { color: '#555', fontSize: '0.9rem', marginBottom: '8px' },
  detailGrid: { marginTop: '16px', marginBottom: '24px' },
  notesBox: { background: '#fef9c3', border: '1px solid #fde68a', borderRadius: '8px', padding: '16px', marginBottom: '20px' },
  notesTitle: { fontWeight: 700, color: '#a16207', marginBottom: '8px', fontSize: '0.9rem' },
  notesText: { color: '#1f2937', fontSize: '0.9rem' },
  renewBtn: {
    display: 'inline-block', background: '#1a4a8a', color: 'white',
    padding: '12px 24px', borderRadius: '8px', textDecoration: 'none', fontWeight: 600,
  },
};

export default VisaStatus;
