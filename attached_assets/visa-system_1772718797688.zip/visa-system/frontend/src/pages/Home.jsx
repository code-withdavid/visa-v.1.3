// pages/Home.jsx
import { Link } from 'react-router-dom';

const features = [
  { icon: '📋', title: 'Easy Application', desc: 'Apply for any visa type with our simple step-by-step form.' },
  { icon: '🔍', title: 'Real-Time Tracking', desc: 'Track your visa status with a live visual timeline.' },
  { icon: '🔄', title: 'Hassle-Free Renewal', desc: 'Renew existing visas before they expire in a few clicks.' },
  { icon: '🤖', title: 'AI Fraud Detection', desc: 'Advanced AI ensures your application is secure and authentic.' },
  { icon: '📧', title: 'Email Notifications', desc: 'Get notified at every stage of your application.' },
  { icon: '🔒', title: 'Secure & Private', desc: 'JWT-secured platform keeps your data safe at all times.' },
];

const visaTypes = ['Tourist', 'Student', 'Work', 'Business', 'Transit', 'Medical'];

const Home = () => (
  <div>
    {/* Hero Section */}
    <section style={styles.hero}>
      <div style={styles.heroContent}>
        <h1 style={styles.heroTitle}>
          Your Visa Journey,<br />
          <span style={styles.heroHighlight}>Simplified.</span>
        </h1>
        <p style={styles.heroSubtitle}>
          Apply, track, and renew visas online — faster, smarter, and stress-free.
        </p>
        <div style={styles.heroBtns}>
          <Link to="/apply" style={styles.primaryBtn}>Apply Now →</Link>
          <Link to="/status" style={styles.secondaryBtn}>Track Status</Link>
        </div>
      </div>
      <div style={styles.heroGraphic}>
        <div style={styles.passportCard}>
          <p style={{ opacity: 0.7, fontSize: '0.8rem' }}>STATUS</p>
          <p style={{ fontSize: '1.4rem', fontWeight: 700, color: '#22c55e' }}>✅ APPROVED</p>
          <p style={{ opacity: 0.7, fontSize: '0.8rem', marginTop: '8px' }}>VIS-2024-XK7B2Q</p>
        </div>
      </div>
    </section>

    {/* Visa Types */}
    <section style={styles.section}>
      <h2 style={styles.sectionTitle}>Visa Types We Process</h2>
      <div style={styles.typeGrid}>
        {visaTypes.map(type => (
          <div key={type} style={styles.typeCard}>
            <span style={styles.typeLabel}>{type}</span>
          </div>
        ))}
      </div>
    </section>

    {/* Features */}
    <section style={{ ...styles.section, background: '#f0f4ff' }}>
      <h2 style={styles.sectionTitle}>Why Choose Us?</h2>
      <div style={styles.featureGrid}>
        {features.map(f => (
          <div key={f.title} style={styles.featureCard}>
            <div style={styles.featureIcon}>{f.icon}</div>
            <h3 style={styles.featureTitle}>{f.title}</h3>
            <p style={styles.featureDesc}>{f.desc}</p>
          </div>
        ))}
      </div>
    </section>

    {/* CTA */}
    <section style={styles.cta}>
      <h2 style={{ fontSize: '1.8rem', marginBottom: '16px' }}>Ready to Apply?</h2>
      <p style={{ opacity: 0.85, marginBottom: '28px' }}>Create your free account and submit your application today.</p>
      <Link to="/register" style={styles.ctaBtn}>Get Started — It's Free</Link>
    </section>
  </div>
);

const styles = {
  hero: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: '80px 10%',
    background: 'linear-gradient(135deg, #0f2c54 0%, #1a4a8a 60%, #1e5fa8 100%)',
    color: 'white',
    gap: '40px',
    flexWrap: 'wrap',
  },
  heroContent: { flex: 1, minWidth: '280px' },
  heroTitle: { fontSize: 'clamp(2rem, 4vw, 3.2rem)', fontWeight: 800, lineHeight: 1.2, marginBottom: '20px' },
  heroHighlight: { color: '#f0a500' },
  heroSubtitle: { fontSize: '1.1rem', opacity: 0.9, marginBottom: '32px', lineHeight: 1.6 },
  heroBtns: { display: 'flex', gap: '16px', flexWrap: 'wrap' },
  primaryBtn: {
    background: '#f0a500', color: '#0f2c54', padding: '14px 32px',
    borderRadius: '8px', textDecoration: 'none', fontWeight: 700, fontSize: '1rem',
  },
  secondaryBtn: {
    background: 'rgba(255,255,255,0.15)', color: 'white', padding: '14px 32px',
    borderRadius: '8px', textDecoration: 'none', border: '2px solid rgba(255,255,255,0.4)', fontSize: '1rem',
  },
  heroGraphic: { flex: '0 0 auto' },
  passportCard: {
    background: 'rgba(255,255,255,0.1)', border: '1px solid rgba(255,255,255,0.2)',
    borderRadius: '16px', padding: '32px 48px', backdropFilter: 'blur(10px)',
    textAlign: 'center',
  },
  section: { padding: '70px 10%', textAlign: 'center' },
  sectionTitle: { fontSize: '1.9rem', fontWeight: 700, color: '#0f2c54', marginBottom: '40px' },
  typeGrid: { display: 'flex', gap: '12px', flexWrap: 'wrap', justifyContent: 'center' },
  typeCard: {
    background: '#0f2c54', color: 'white', padding: '12px 28px',
    borderRadius: '30px', fontSize: '0.95rem', fontWeight: 500,
  },
  typeLabel: {},
  featureGrid: {
    display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))',
    gap: '24px', textAlign: 'left',
  },
  featureCard: {
    background: 'white', padding: '28px', borderRadius: '12px',
    boxShadow: '0 2px 12px rgba(0,0,0,0.07)',
  },
  featureIcon: { fontSize: '2rem', marginBottom: '12px' },
  featureTitle: { fontSize: '1.05rem', fontWeight: 700, color: '#0f2c54', marginBottom: '8px' },
  featureDesc: { color: '#555', fontSize: '0.9rem', lineHeight: 1.6 },
  cta: {
    background: '#0f2c54', color: 'white',
    padding: '70px 10%', textAlign: 'center',
  },
  ctaBtn: {
    background: '#f0a500', color: '#0f2c54', padding: '16px 40px',
    borderRadius: '8px', textDecoration: 'none', fontWeight: 700, fontSize: '1.05rem',
  },
};

export default Home;
