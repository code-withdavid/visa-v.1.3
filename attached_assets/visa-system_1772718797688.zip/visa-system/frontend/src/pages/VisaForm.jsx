// pages/VisaForm.jsx
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const API = 'http://localhost:5000/api';

const VISA_TYPES = ['tourist', 'student', 'work', 'business', 'transit', 'medical'];

const VisaForm = () => {
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [form, setForm] = useState({
    visa_type: '',
    destination_country: '',
    travel_date: '',
    return_date: '',
    duration_of_stay: '',
    purpose_of_visit: '',
  });
  const [uploadFile, setUploadFile] = useState(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [submitted, setSubmitted] = useState(null);

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleNext = (e) => {
    e.preventDefault();
    setStep(2);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const token = localStorage.getItem('token');

      // Step 1: Submit visa application
      const res = await fetch(`${API}/apply-visa`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({
          ...form,
          duration_of_stay: parseInt(form.duration_of_stay, 10),
        }),
      });
      const data = await res.json();

      if (!data.success) {
        setError(data.message || 'Application failed');
        setLoading(false);
        return;
      }

      // Step 2: Upload document if provided
      if (uploadFile && data.visa_id) {
        const formData = new FormData();
        formData.append('file', uploadFile);
        formData.append('visa_id', data.visa_id);
        formData.append('document_type', 'passport');

        await fetch(`${API}/upload-document`, {
          method: 'POST',
          headers: { Authorization: `Bearer ${token}` },
          body: formData,
        });
      }

      setSubmitted(data);
    } catch {
      setError('Cannot connect to server. Make sure the backend is running.');
    } finally {
      setLoading(false);
    }
  };

  if (submitted) {
    return (
      <div style={styles.page}>
        <div style={styles.successCard}>
          <div style={styles.successIcon}>🎉</div>
          <h2 style={styles.successTitle}>Application Submitted!</h2>
          <p style={styles.successMsg}>Your visa application has been received and is being processed.</p>
          <div style={styles.appNumberBox}>
            <span style={styles.appNumLabel}>Application Number</span>
            <code style={styles.appNum}>{submitted.application_number}</code>
          </div>
          <p style={styles.infoMsg}>📧 You'll receive email updates as your application progresses.</p>
          <div style={styles.successBtns}>
            <button onClick={() => navigate('/dashboard')} style={styles.dashBtn}>Go to Dashboard</button>
            <button onClick={() => navigate('/status')} style={styles.trackBtn}>Track Status</button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div style={styles.page}>
      <div style={styles.card}>
        <div style={styles.cardHeader}>
          <h2 style={styles.cardTitle}>🌍 Visa Application Form</h2>
          <div style={styles.stepIndicator}>
            <span style={{ ...styles.stepDot, background: '#0f2c54' }}>1</span>
            <span style={styles.stepLine} />
            <span style={{ ...styles.stepDot, background: step === 2 ? '#0f2c54' : '#d1d5db' }}>2</span>
          </div>
        </div>

        {error && <div style={styles.error}>⚠️ {error}</div>}

        {step === 1 && (
          <form onSubmit={handleNext}>
            <h3 style={styles.stepTitle}>Step 1: Trip Details</h3>

            <div style={styles.field}>
              <label style={styles.label}>Visa Type *</label>
              <select name="visa_type" value={form.visa_type} onChange={handleChange} required style={styles.input}>
                <option value="">— Select visa type —</option>
                {VISA_TYPES.map(t => (
                  <option key={t} value={t}>{t.charAt(0).toUpperCase() + t.slice(1)}</option>
                ))}
              </select>
            </div>

            <div style={styles.field}>
              <label style={styles.label}>Destination Country *</label>
              <input type="text" name="destination_country" value={form.destination_country}
                onChange={handleChange} required placeholder="e.g. France" style={styles.input} />
            </div>

            <div style={styles.grid}>
              <div style={styles.field}>
                <label style={styles.label}>Travel Date *</label>
                <input type="date" name="travel_date" value={form.travel_date}
                  onChange={handleChange} required style={styles.input} />
              </div>
              <div style={styles.field}>
                <label style={styles.label}>Return Date *</label>
                <input type="date" name="return_date" value={form.return_date}
                  onChange={handleChange} required style={styles.input} />
              </div>
            </div>

            <div style={styles.field}>
              <label style={styles.label}>Duration of Stay (days) *</label>
              <input type="number" name="duration_of_stay" value={form.duration_of_stay}
                onChange={handleChange} required min="1" max="365" placeholder="e.g. 14" style={styles.input} />
            </div>

            <div style={styles.field}>
              <label style={styles.label}>Purpose of Visit *</label>
              <textarea name="purpose_of_visit" value={form.purpose_of_visit}
                onChange={handleChange} required rows={3}
                placeholder="Describe the reason for your visit..."
                style={{ ...styles.input, resize: 'vertical' }} />
            </div>

            <button type="submit" style={styles.btn}>Next: Upload Documents →</button>
          </form>
        )}

        {step === 2 && (
          <form onSubmit={handleSubmit}>
            <h3 style={styles.stepTitle}>Step 2: Upload Documents</h3>

            <div style={styles.reviewBox}>
              <h4 style={styles.reviewTitle}>Application Summary</h4>
              <div style={styles.reviewGrid}>
                <ReviewItem label="Visa Type" value={form.visa_type} />
                <ReviewItem label="Destination" value={form.destination_country} />
                <ReviewItem label="Travel Date" value={form.travel_date} />
                <ReviewItem label="Return Date" value={form.return_date} />
                <ReviewItem label="Duration" value={`${form.duration_of_stay} days`} />
              </div>
            </div>

            <div style={styles.field}>
              <label style={styles.label}>Upload Passport / Main Document (Optional)</label>
              <div style={styles.uploadArea}>
                <input
                  type="file"
                  accept=".pdf,.jpg,.jpeg,.png"
                  onChange={(e) => setUploadFile(e.target.files[0])}
                  style={{ marginBottom: '8px' }}
                />
                <p style={styles.uploadHint}>Accepted: PDF, JPG, JPEG, PNG (max 5MB)</p>
              </div>
              {uploadFile && <p style={styles.uploadedFile}>📎 {uploadFile.name}</p>}
            </div>

            <div style={styles.btnRow}>
              <button type="button" onClick={() => setStep(1)} style={styles.backBtn}>← Back</button>
              <button type="submit" disabled={loading} style={styles.btn}>
                {loading ? 'Submitting...' : '✅ Submit Application'}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};

const ReviewItem = ({ label, value }) => (
  <div style={{ marginBottom: '8px' }}>
    <span style={{ fontSize: '0.8rem', color: '#666' }}>{label}: </span>
    <span style={{ fontWeight: 600, color: '#0f2c54' }}>{value}</span>
  </div>
);

const styles = {
  page: { padding: '40px 20px', background: '#f0f4ff', minHeight: '80vh', display: 'flex', justifyContent: 'center', alignItems: 'flex-start' },
  card: { background: 'white', borderRadius: '16px', padding: '40px', width: '100%', maxWidth: '600px', boxShadow: '0 4px 24px rgba(0,0,0,0.1)' },
  cardHeader: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '28px' },
  cardTitle: { fontSize: '1.5rem', fontWeight: 800, color: '#0f2c54' },
  stepIndicator: { display: 'flex', alignItems: 'center', gap: '8px' },
  stepDot: { width: '28px', height: '28px', borderRadius: '50%', color: 'white', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '0.85rem', fontWeight: 700 },
  stepLine: { width: '30px', height: '2px', background: '#d1d5db' },
  stepTitle: { fontSize: '1rem', fontWeight: 700, color: '#374151', marginBottom: '24px' },
  error: { background: '#fef2f2', border: '1px solid #fecaca', color: '#dc2626', padding: '12px 16px', borderRadius: '8px', marginBottom: '20px', fontSize: '0.9rem' },
  field: { marginBottom: '20px' },
  label: { display: 'block', fontSize: '0.9rem', fontWeight: 600, color: '#374151', marginBottom: '6px' },
  input: { width: '100%', padding: '11px 13px', borderRadius: '7px', border: '2px solid #e5e7eb', fontSize: '0.9rem', outline: 'none', boxSizing: 'border-box' },
  grid: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' },
  reviewBox: { background: '#f8faff', border: '1px solid #dbeafe', borderRadius: '10px', padding: '20px', marginBottom: '24px' },
  reviewTitle: { fontWeight: 700, color: '#1d4ed8', marginBottom: '12px', fontSize: '0.95rem' },
  reviewGrid: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '4px' },
  uploadArea: { border: '2px dashed #d1d5db', borderRadius: '8px', padding: '20px', textAlign: 'center' },
  uploadHint: { fontSize: '0.8rem', color: '#9ca3af', margin: 0 },
  uploadedFile: { color: '#15803d', fontSize: '0.85rem', marginTop: '8px' },
  btnRow: { display: 'flex', gap: '16px', marginTop: '8px' },
  btn: { flex: 1, padding: '14px', background: '#0f2c54', color: 'white', border: 'none', borderRadius: '8px', fontSize: '1rem', fontWeight: 700, cursor: 'pointer' },
  backBtn: { padding: '14px 20px', background: 'white', color: '#374151', border: '2px solid #e5e7eb', borderRadius: '8px', cursor: 'pointer', fontWeight: 600 },
  successCard: { background: 'white', borderRadius: '16px', padding: '60px 48px', width: '100%', maxWidth: '500px', textAlign: 'center', boxShadow: '0 4px 24px rgba(0,0,0,0.1)' },
  successIcon: { fontSize: '4rem', marginBottom: '16px' },
  successTitle: { fontSize: '1.8rem', fontWeight: 800, color: '#0f2c54', marginBottom: '12px' },
  successMsg: { color: '#666', marginBottom: '28px' },
  appNumberBox: { background: '#f0f4ff', border: '1px solid #dbeafe', borderRadius: '10px', padding: '20px', marginBottom: '16px', display: 'flex', flexDirection: 'column', gap: '6px' },
  appNumLabel: { fontSize: '0.8rem', color: '#666' },
  appNum: { fontSize: '1.2rem', fontWeight: 700, color: '#0f2c54' },
  infoMsg: { color: '#666', fontSize: '0.9rem', marginBottom: '28px' },
  successBtns: { display: 'flex', gap: '12px', justifyContent: 'center' },
  dashBtn: { padding: '12px 24px', background: '#0f2c54', color: 'white', border: 'none', borderRadius: '8px', fontWeight: 600, cursor: 'pointer' },
  trackBtn: { padding: '12px 24px', background: 'white', color: '#0f2c54', border: '2px solid #0f2c54', borderRadius: '8px', fontWeight: 600, cursor: 'pointer' },
};

export default VisaForm;
