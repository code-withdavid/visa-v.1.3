# 🛂 Online Visa Granted and Renewal Information System

A full-stack web application for managing visa applications, tracking statuses, and handling renewals.

**Tech Stack:** React (Frontend) · Python Flask (Backend) · MySQL (Database)

---

## 📁 Project Structure

```
visa-system/
├── frontend/               # React application (Vite)
│   ├── src/
│   │   ├── components/
│   │   │   ├── Navbar.jsx
│   │   │   ├── Footer.jsx
│   │   │   └── StatusTimeline.jsx
│   │   ├── pages/
│   │   │   ├── Home.jsx
│   │   │   ├── Login.jsx
│   │   │   ├── Register.jsx
│   │   │   ├── Dashboard.jsx
│   │   │   ├── VisaForm.jsx
│   │   │   ├── VisaStatus.jsx
│   │   │   └── Renewal.jsx
│   │   ├── App.jsx
│   │   └── main.jsx
│   ├── package.json
│   └── index.html
│
├── backend/                # Flask REST API
│   ├── app.py              ← Main entry point
│   ├── requirements.txt
│   ├── .env.example        ← Copy to .env and configure
│   ├── config/
│   │   └── db.py           ← MySQL connection
│   ├── routes/
│   │   ├── auth_routes.py  ← /register, /login, /me
│   │   └── visa_routes.py  ← /apply-visa, /visa-status, etc.
│   ├── controllers/
│   │   ├── auth_controller.py
│   │   └── visa_controller.py
│   ├── models/
│   │   ├── user_model.py
│   │   └── visa_model.py
│   ├── services/
│   │   ├── ai_fraud_detection.py   ← AI fraud check placeholder
│   │   └── notification_service.py ← Email notifications
│   ├── middleware/
│   │   └── auth_middleware.py      ← JWT decorators
│   ├── utils/
│   │   └── file_upload.py          ← Secure file handling
│   └── uploads/                    ← Uploaded documents stored here
│
└── database/
    └── schema.sql          ← MySQL table definitions
```

---

## 🚀 How to Run Locally (Step by Step)

### Prerequisites
- Python 3.10 or higher
- Node.js 18 or higher
- MySQL Server 8.0 or higher
- Git (optional)

---

### STEP 1 — Set Up the Database

1. Open MySQL Workbench or your MySQL terminal
2. Run the schema file:

```sql
SOURCE /path/to/visa-system/database/schema.sql;
```

Or copy-paste the contents of `database/schema.sql` into your MySQL client and execute it.

This creates the `visa_system` database with all required tables.

---

### STEP 2 — Configure the Backend

1. Navigate to the backend folder:
```bash
cd visa-system/backend
```

2. Create a virtual environment:
```bash
python -m venv venv
```

3. Activate it:
```bash
# Windows:
venv\Scripts\activate

# Mac/Linux:
source venv/bin/activate
```

4. Install dependencies:
```bash
pip install -r requirements.txt
```

5. Create your `.env` file:
```bash
cp .env.example .env
```

6. Edit `.env` with your settings:
```env
DB_HOST=localhost
DB_USER=root
DB_PASSWORD=your_mysql_password_here
DB_NAME=visa_system
SECRET_KEY=any-random-string-here
JWT_SECRET_KEY=another-random-string-here
```

---

### STEP 3 — Run the Backend

```bash
# Make sure you're in the backend/ folder with venv activated
python app.py
```

You should see:
```
╔══════════════════════════════════════════════╗
║   Online Visa Granted & Renewal System       ║
║   Flask API Server                           ║
║   Running at: http://localhost:5000          ║
╚══════════════════════════════════════════════╝
```

Test it works: http://localhost:5000/api/health

---

### STEP 4 — Run the Frontend

Open a **new terminal** and:

```bash
cd visa-system/frontend
npm install
npm run dev
```

The app will open at: **http://localhost:3000**

---

## 🔑 API Endpoints

| Method | Endpoint | Auth Required | Description |
|--------|----------|--------------|-------------|
| POST | `/api/register` | No | Register new user |
| POST | `/api/login` | No | Login, get JWT token |
| GET | `/api/me` | Yes | Get current user |
| POST | `/api/apply-visa` | Yes | Submit new visa application |
| GET | `/api/visa-status` | Yes | Get all visas for user |
| GET | `/api/visa-status?application_number=VIS-...` | Yes | Get specific visa |
| POST | `/api/renew-visa` | Yes | Submit renewal application |
| POST | `/api/upload-document` | Yes | Upload a document |
| GET | `/api/admin/visas` | Admin Only | List all applications |
| PUT | `/api/admin/visa/<id>` | Admin Only | Approve/reject visa |

**Authentication:** Include the token in headers:
```
Authorization: Bearer <your_jwt_token>
```

---

## 📋 Database Tables

| Table | Description |
|-------|-------------|
| `users` | User accounts (applicants + admins) |
| `visas` | All visa applications and renewals |
| `documents` | Uploaded files metadata |
| `notifications` | System and email notifications log |

---

## ✨ Features

- ✅ User registration and login with JWT authentication
- ✅ Multi-step visa application form with validation
- ✅ Document upload (passport, photo, supporting docs)
- ✅ Real-time visa status tracking with visual timeline
- ✅ Visa renewal workflow
- ✅ Admin approval/rejection system with notes
- ✅ AI fraud detection (rule-based scoring system)
- ✅ Email notification service (console mode + SMTP)
- ✅ Protected routes (frontend + backend)
- ✅ Responsive design

---

## 🤖 AI Fraud Detection Module

Located in `backend/services/ai_fraud_detection.py`

The module scores each application from 0.0 (safe) to 1.0 (high risk) based on:
- Unusually long stay duration
- Travel date is too soon
- Inconsistent dates (return before travel)
- Missing or vague purpose
- High-risk visa type with short notice

Applications with score ≥ 0.4 are flagged for admin review.

> In a real production system, this would connect to a trained ML model or external fraud detection API.

---

## 🛠 Troubleshooting

**"Cannot connect to server" error in React:**
- Make sure Flask is running on port 5000
- Check that CORS is not blocked

**MySQL connection error:**
- Verify your DB_PASSWORD in `.env`
- Make sure MySQL service is running

**"Module not found" error in Flask:**
- Make sure your virtual environment is activated
- Run `pip install -r requirements.txt` again

---

## 📝 Notes for Submission

This project demonstrates:
1. **Full-Stack Architecture** — Separation of React frontend and Flask REST API
2. **MVC Pattern** — Routes → Controllers → Models
3. **Security** — bcrypt password hashing, JWT authentication, file validation
4. **Database Design** — Normalized relational schema with foreign keys
5. **AI Integration** — Fraud detection scoring module
6. **Service Layer** — Notification and fraud detection as separate services
