# app.py
# ============================================================
# Online Visa Granted and Renewal Information System
# Main Flask Application Entry Point
# ============================================================

from flask import Flask, jsonify
from flask_cors import CORS
from flask_jwt_extended import JWTManager
from dotenv import load_dotenv
import os

# Load environment variables from .env file
load_dotenv()

# Import route blueprints
from routes.auth_routes import auth_bp
from routes.visa_routes import visa_bp


def create_app():
    """
    Application Factory Pattern.
    Creates and configures the Flask application.
    """
    app = Flask(__name__)

    # --------------------------------------------------------
    # Configuration
    # --------------------------------------------------------
    app.config['SECRET_KEY'] = os.getenv('SECRET_KEY', 'dev-secret-key-change-in-production')
    app.config['JWT_SECRET_KEY'] = os.getenv('JWT_SECRET_KEY', 'jwt-secret-change-in-production')
    app.config['MAX_CONTENT_LENGTH'] = int(os.getenv('MAX_CONTENT_LENGTH', 16 * 1024 * 1024))  # 16MB

    # --------------------------------------------------------
    # Extensions
    # --------------------------------------------------------
    
    # CORS: Allow requests from the React frontend (port 3000)
    CORS(app, resources={
        r"/*": {
            "origins": ["http://localhost:3000", "http://127.0.0.1:3000"],
            "methods": ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
            "allow_headers": ["Content-Type", "Authorization"]
        }
    })

    # JWT Manager for token-based authentication
    jwt = JWTManager(app)

    # Custom JWT error responses
    @jwt.unauthorized_loader
    def unauthorized_response(callback):
        return jsonify({'success': False, 'message': 'Missing or invalid authorization token'}), 401

    @jwt.expired_token_loader
    def expired_token_response(jwt_header, jwt_payload):
        return jsonify({'success': False, 'message': 'Your session has expired. Please log in again.'}), 401

    # --------------------------------------------------------
    # Register Route Blueprints
    # All routes are prefixed with /api
    # --------------------------------------------------------
    app.register_blueprint(auth_bp, url_prefix='/api')
    app.register_blueprint(visa_bp, url_prefix='/api')

    # --------------------------------------------------------
    # Health Check Endpoint
    # --------------------------------------------------------
    @app.route('/api/health', methods=['GET'])
    def health_check():
        """Simple endpoint to verify the API is running."""
        return jsonify({
            'status': 'healthy',
            'message': 'Visa System API is running',
            'version': '1.0.0'
        }), 200

    # --------------------------------------------------------
    # 404 Handler
    # --------------------------------------------------------
    @app.errorhandler(404)
    def not_found(error):
        return jsonify({'success': False, 'message': 'Endpoint not found'}), 404

    # --------------------------------------------------------
    # 500 Handler
    # --------------------------------------------------------
    @app.errorhandler(500)
    def server_error(error):
        return jsonify({'success': False, 'message': 'Internal server error'}), 500

    return app


# --------------------------------------------------------
# Run the application
# --------------------------------------------------------
if __name__ == '__main__':
    app = create_app()
    port = int(os.getenv('PORT', 5000))
    debug = os.getenv('FLASK_DEBUG', 'True').lower() == 'true'
    
    print(f"""
    ╔══════════════════════════════════════════════╗
    ║   Online Visa Granted & Renewal System       ║
    ║   Flask API Server                           ║
    ║   Running at: http://localhost:{port}           ║
    ╚══════════════════════════════════════════════╝
    """)
    
    app.run(host='0.0.0.0', port=port, debug=debug)
