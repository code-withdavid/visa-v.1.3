# utils/file_upload.py
# ============================================================
# File Upload Utility
# Handles secure file saving for document uploads
# ============================================================

import os
import uuid
from werkzeug.utils import secure_filename

# Allowed file extensions for uploaded documents
ALLOWED_EXTENSIONS = {'pdf', 'jpg', 'jpeg', 'png'}

# Max file size: 5MB
MAX_FILE_SIZE = 5 * 1024 * 1024


def allowed_file(filename):
    """
    Checks if the uploaded file has an allowed extension.
    Returns True if allowed, False otherwise.
    """
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


def save_uploaded_file(file, visa_id):
    """
    Saves an uploaded file securely to the uploads directory.
    
    - Sanitizes the filename using werkzeug's secure_filename
    - Renames the file with a UUID to prevent overwrites
    - Creates a subfolder per visa_id for organization
    
    Returns:
        dict with success status and file metadata
    """
    if not file:
        return {'success': False, 'message': 'No file provided'}

    if file.filename == '':
        return {'success': False, 'message': 'No file selected'}

    if not allowed_file(file.filename):
        return {
            'success': False,
            'message': f'File type not allowed. Accepted: {", ".join(ALLOWED_EXTENSIONS)}'
        }

    # Sanitize original filename (removes dangerous characters)
    original_filename = secure_filename(file.filename)
    
    # Get file extension
    extension = original_filename.rsplit('.', 1)[1].lower()
    
    # Generate a unique filename to prevent overwriting
    stored_filename = f"{uuid.uuid4().hex}.{extension}"

    # Create upload directory (organized by visa_id)
    upload_base = os.getenv('UPLOAD_FOLDER', 'uploads')
    visa_folder = os.path.join(upload_base, str(visa_id))
    os.makedirs(visa_folder, exist_ok=True)  # Create folder if it doesn't exist

    file_path = os.path.join(visa_folder, stored_filename)

    # Read file content to check size before saving
    file.seek(0, 2)  # Seek to end
    file_size = file.tell()
    file.seek(0)     # Reset to beginning

    if file_size > MAX_FILE_SIZE:
        return {'success': False, 'message': 'File too large. Maximum size is 5MB'}

    # Save the file
    file.save(file_path)

    return {
        'success': True,
        'original_filename': original_filename,
        'stored_filename': stored_filename,
        'file_path': file_path,
        'file_size': file_size,
        'mime_type': get_mime_type(extension)
    }


def get_mime_type(extension):
    """Returns the MIME type for common file extensions."""
    mime_types = {
        'pdf': 'application/pdf',
        'jpg': 'image/jpeg',
        'jpeg': 'image/jpeg',
        'png': 'image/png'
    }
    return mime_types.get(extension, 'application/octet-stream')
