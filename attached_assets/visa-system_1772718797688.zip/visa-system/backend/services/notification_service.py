# services/notification_service.py
# ============================================================
# Notification Service
# Handles email notifications and in-system notifications
# 
# Email sending is simulated (console output) unless a real
# SMTP server is configured in .env
# ============================================================

import os
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from config.db import get_db_connection
from datetime import datetime


def send_notification(user_id, visa_id, notification_type, message, subject=None):
    """
    Saves a notification to the database AND attempts to send an email.
    
    Parameters:
        user_id (int): The user to notify
        visa_id (int): Related visa application (can be None)
        notification_type (str): Type of notification
        message (str): The notification body
        subject (str): Email subject (auto-generated if None)
    """
    # Auto-generate subject if not provided
    if not subject:
        subject = get_default_subject(notification_type)

    # --- Step 1: Save to notifications table ---
    save_notification_to_db(user_id, visa_id, notification_type, subject, message)

    # --- Step 2: Get user email for sending ---
    user_email = get_user_email(user_id)

    # --- Step 3: Send email (if SMTP is configured) ---
    if user_email:
        try:
            send_email(user_email, subject, message)
        except Exception as e:
            # Don't crash the app if email fails - just log it
            print(f"[NOTIFICATION] Email send failed for user {user_id}: {e}")
            print(f"[NOTIFICATION] Would have sent: To={user_email}, Subject={subject}")
    
    # Always log notifications for debugging/demo purposes
    print(f"[NOTIFICATION {datetime.now()}] User {user_id} | Type: {notification_type} | {message}")


def save_notification_to_db(user_id, visa_id, notification_type, subject, message):
    """Persists the notification record to the database."""
    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            sql = """
                INSERT INTO notifications (user_id, visa_id, notification_type, subject, message)
                VALUES (%s, %s, %s, %s, %s)
            """
            cursor.execute(sql, (user_id, visa_id, notification_type, subject, message))
            conn.commit()
    except Exception as e:
        print(f"[NOTIFICATION DB ERROR] {e}")
    finally:
        conn.close()


def get_user_email(user_id):
    """Retrieves the user's email address from the database."""
    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute("SELECT email FROM users WHERE id = %s", (user_id,))
            result = cursor.fetchone()
            return result['email'] if result else None
    finally:
        conn.close()


def send_email(to_email, subject, message):
    """
    Sends an email using SMTP.
    Uses environment variables for configuration.
    Falls back to console output if not configured.
    """
    mail_server = os.getenv('MAIL_SERVER', '')
    mail_username = os.getenv('MAIL_USERNAME', '')
    mail_password = os.getenv('MAIL_PASSWORD', '')
    mail_port = int(os.getenv('MAIL_PORT', 587))
    sender = os.getenv('MAIL_DEFAULT_SENDER', 'noreply@visasystem.com')

    # If no mail server configured, just print (demo mode)
    if not mail_server or not mail_username:
        print(f"[EMAIL DEMO] To: {to_email} | Subject: {subject} | Body: {message}")
        return

    # Build email
    msg = MIMEMultipart('alternative')
    msg['Subject'] = subject
    msg['From'] = sender
    msg['To'] = to_email

    # Plain text version
    text_part = MIMEText(message, 'plain')
    
    # HTML version
    html_body = f"""
    <html>
    <body style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
        <div style="background: #1a3c5e; color: white; padding: 20px; border-radius: 8px 8px 0 0;">
            <h2>🛂 Visa Information System</h2>
        </div>
        <div style="background: #f9f9f9; padding: 20px; border-radius: 0 0 8px 8px; border: 1px solid #ddd;">
            <p>{message}</p>
            <hr>
            <p style="color: #888; font-size: 12px;">This is an automated message. Please do not reply.</p>
        </div>
    </body>
    </html>
    """
    html_part = MIMEText(html_body, 'html')
    
    msg.attach(text_part)
    msg.attach(html_part)

    # Send via SMTP
    with smtplib.SMTP(mail_server, mail_port) as server:
        server.starttls()
        server.login(mail_username, mail_password)
        server.sendmail(sender, to_email, msg.as_string())


def get_default_subject(notification_type):
    """Returns a default email subject based on notification type."""
    subjects = {
        'application_received': '✅ Visa Application Received',
        'status_update': '📋 Visa Application Status Update',
        'approval': '🎉 Your Visa Application Has Been Approved!',
        'rejection': '❌ Visa Application Decision',
        'renewal_reminder': '⏰ Visa Renewal Reminder',
        'expiry_warning': '⚠️ Your Visa is Expiring Soon'
    }
    return subjects.get(notification_type, 'Visa System Notification')
