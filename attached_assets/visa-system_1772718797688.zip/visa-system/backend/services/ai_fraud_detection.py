# services/ai_fraud_detection.py
# ============================================================
# AI Fraud Detection Service (Placeholder Module)
# 
# This module simulates an AI-powered fraud detection system.
# In a real system, this would call a trained ML model or
# external fraud detection API (e.g. AWS Fraud Detector).
#
# For this project, it uses rule-based heuristics to generate
# a fraud risk score between 0.0 (safe) and 1.0 (high risk).
# ============================================================

from datetime import datetime, date


def analyze_application(application_data):
    """
    Analyzes a visa application for potential fraud indicators.
    
    Parameters:
        application_data (dict): The visa application form data
    
    Returns:
        dict: {
            'score': float (0.0 - 1.0),  # fraud probability
            'flagged': bool,              # True if score > threshold
            'reasons': list              # List of detected risk factors
        }
    """
    score = 0.0
    reasons = []

    # --- Rule 1: Unusually long duration of stay ---
    try:
        duration = int(application_data.get('duration_of_stay', 0))
        if duration > 180:
            score += 0.2
            reasons.append('Requested duration exceeds 180 days')
        elif duration > 90:
            score += 0.1
            reasons.append('Long duration stay requested (90+ days)')
    except (ValueError, TypeError):
        pass

    # --- Rule 2: Travel date is suspiciously soon (within 3 days) ---
    try:
        travel_date_str = application_data.get('travel_date', '')
        if travel_date_str:
            travel_date = datetime.strptime(travel_date_str, '%Y-%m-%d').date()
            days_until_travel = (travel_date - date.today()).days
            if days_until_travel < 3:
                score += 0.25
                reasons.append('Travel date is within 3 days of application')
            elif days_until_travel < 7:
                score += 0.1
                reasons.append('Very short notice application (less than 1 week)')
    except (ValueError, TypeError):
        pass

    # --- Rule 3: Return date is before travel date ---
    try:
        travel_date_str = application_data.get('travel_date', '')
        return_date_str = application_data.get('return_date', '')
        if travel_date_str and return_date_str:
            travel_date = datetime.strptime(travel_date_str, '%Y-%m-%d').date()
            return_date = datetime.strptime(return_date_str, '%Y-%m-%d').date()
            if return_date <= travel_date:
                score += 0.3
                reasons.append('Return date is on or before travel date (inconsistent dates)')
    except (ValueError, TypeError):
        pass

    # --- Rule 4: Missing purpose of visit ---
    purpose = application_data.get('purpose_of_visit', '').strip()
    if not purpose or len(purpose) < 10:
        score += 0.1
        reasons.append('Purpose of visit not provided or too brief')

    # --- Rule 5: High-risk visa type with short notice ---
    visa_type = application_data.get('visa_type', '')
    if visa_type in ['work', 'business'] and days_until_travel_safe(application_data) < 14:
        score += 0.15
        reasons.append('Work/Business visa requested with very short notice')

    # Cap the score at 1.0
    score = min(score, 1.0)

    # Flag if score exceeds threshold (0.4 = 40% fraud risk)
    FRAUD_THRESHOLD = 0.4
    flagged = score >= FRAUD_THRESHOLD

    return {
        'score': round(score, 2),
        'flagged': flagged,
        'reasons': reasons,
        'risk_level': get_risk_level(score)
    }


def days_until_travel_safe(data):
    """Helper: safely calculates days until travel. Returns 999 if dates missing."""
    try:
        travel_date = datetime.strptime(data.get('travel_date', ''), '%Y-%m-%d').date()
        return (travel_date - date.today()).days
    except (ValueError, TypeError):
        return 999


def get_risk_level(score):
    """Converts a fraud score to a human-readable risk level."""
    if score < 0.2:
        return 'LOW'
    elif score < 0.4:
        return 'MEDIUM'
    elif score < 0.7:
        return 'HIGH'
    else:
        return 'CRITICAL'
