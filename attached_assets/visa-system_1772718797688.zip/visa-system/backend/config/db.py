# config/db.py
# ============================================================
# Database Configuration
# Handles MySQL connection using PyMySQL
# ============================================================

import pymysql
import os
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()


def get_db_connection():
    """
    Creates and returns a new MySQL database connection.
    Uses environment variables for credentials.
    Returns a PyMySQL connection with DictCursor so rows come back as dicts.
    """
    try:
        connection = pymysql.connect(
            host=os.getenv('DB_HOST', 'localhost'),
            port=int(os.getenv('DB_PORT', 3306)),
            user=os.getenv('DB_USER', 'root'),
            password=os.getenv('DB_PASSWORD', ''),
            database=os.getenv('DB_NAME', 'visa_system'),
            cursorclass=pymysql.cursors.DictCursor,  # Returns rows as dictionaries
            charset='utf8mb4',
            autocommit=False  # We handle commits manually for safety
        )
        return connection
    except pymysql.Error as e:
        print(f"[DB ERROR] Could not connect to database: {e}")
        raise e
