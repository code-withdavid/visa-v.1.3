# models/user_model.py
# ============================================================
# User Model
# All database operations related to users
# ============================================================

from config.db import get_db_connection
import bcrypt


def create_user(full_name, email, password, phone=None, nationality=None, date_of_birth=None):
    """
    Inserts a new user into the database.
    Hashes the password with bcrypt before storing.
    Returns the new user's ID on success, None on failure.
    """
    # Hash the password - bcrypt adds salt automatically
    password_bytes = password.encode('utf-8')
    hashed_password = bcrypt.hashpw(password_bytes, bcrypt.gensalt())

    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            sql = """
                INSERT INTO users (full_name, email, password_hash, phone, nationality, date_of_birth)
                VALUES (%s, %s, %s, %s, %s, %s)
            """
            cursor.execute(sql, (full_name, email, hashed_password.decode('utf-8'), phone, nationality, date_of_birth))
            conn.commit()
            return cursor.lastrowid  # Return the new user's ID
    except Exception as e:
        conn.rollback()
        print(f"[USER MODEL ERROR] create_user: {e}")
        return None
    finally:
        conn.close()


def find_user_by_email(email):
    """
    Finds a user by their email address.
    Returns the user dict or None if not found.
    """
    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            sql = "SELECT * FROM users WHERE email = %s AND is_active = TRUE"
            cursor.execute(sql, (email,))
            return cursor.fetchone()
    finally:
        conn.close()


def find_user_by_id(user_id):
    """
    Finds a user by their ID.
    Returns the user dict or None if not found.
    """
    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            sql = "SELECT id, full_name, email, phone, nationality, date_of_birth, role, created_at FROM users WHERE id = %s"
            cursor.execute(sql, (user_id,))
            return cursor.fetchone()
    finally:
        conn.close()


def verify_password(plain_password, hashed_password):
    """
    Checks if a plain text password matches the stored hash.
    Returns True if they match, False otherwise.
    """
    password_bytes = plain_password.encode('utf-8')
    hashed_bytes = hashed_password.encode('utf-8')
    return bcrypt.checkpw(password_bytes, hashed_bytes)


def get_all_users():
    """
    Admin function: retrieves all users (excluding password hashes).
    """
    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            sql = "SELECT id, full_name, email, phone, nationality, role, is_active, created_at FROM users ORDER BY created_at DESC"
            cursor.execute(sql)
            return cursor.fetchall()
    finally:
        conn.close()
