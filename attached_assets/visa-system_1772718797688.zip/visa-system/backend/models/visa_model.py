# models/visa_model.py
# ============================================================
# Visa Model
# All database operations related to visa applications
# ============================================================

from config.db import get_db_connection
import random
import string
from datetime import datetime


def generate_application_number():
    """
    Generates a unique application number like: VIS-2024-ABCD1234
    """
    year = datetime.now().year
    random_part = ''.join(random.choices(string.ascii_uppercase + string.digits, k=8))
    return f"VIS-{year}-{random_part}"


def create_visa_application(user_id, visa_type, purpose, destination_country,
                             travel_date, return_date, duration_of_stay,
                             application_type='new', previous_visa_id=None,
                             fraud_score=0.0, fraud_flagged=False):
    """
    Creates a new visa application in the database.
    Returns the new visa's ID and application number on success.
    """
    app_number = generate_application_number()

    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            sql = """
                INSERT INTO visas 
                (user_id, application_number, visa_type, purpose_of_visit, destination_country,
                 travel_date, return_date, duration_of_stay, application_type, previous_visa_id,
                 fraud_score, fraud_flagged, status)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, 'pending')
            """
            cursor.execute(sql, (
                user_id, app_number, visa_type, purpose, destination_country,
                travel_date, return_date, duration_of_stay, application_type,
                previous_visa_id, fraud_score, fraud_flagged
            ))
            conn.commit()
            return cursor.lastrowid, app_number
    except Exception as e:
        conn.rollback()
        print(f"[VISA MODEL ERROR] create_visa_application: {e}")
        return None, None
    finally:
        conn.close()


def get_visa_by_id(visa_id):
    """Returns a single visa by its database ID."""
    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            sql = "SELECT * FROM visas WHERE id = %s"
            cursor.execute(sql, (visa_id,))
            return cursor.fetchone()
    finally:
        conn.close()


def get_visas_by_user(user_id):
    """Returns all visa applications for a specific user, newest first."""
    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            sql = "SELECT * FROM visas WHERE user_id = %s ORDER BY created_at DESC"
            cursor.execute(sql, (user_id,))
            return cursor.fetchall()
    finally:
        conn.close()


def get_visa_by_application_number(app_number):
    """Looks up a visa using the application number (e.g. VIS-2024-XXXX)."""
    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            sql = "SELECT * FROM visas WHERE application_number = %s"
            cursor.execute(sql, (app_number,))
            return cursor.fetchone()
    finally:
        conn.close()


def update_visa_status(visa_id, new_status, admin_notes=None, expiry_date=None):
    """
    Updates a visa's status.
    Called by admin when approving/rejecting applications.
    """
    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            # Build query depending on whether we're approving (sets expiry) or rejecting
            if new_status == 'approved':
                sql = """
                    UPDATE visas 
                    SET status = %s, admin_notes = %s, expiry_date = %s, 
                        approved_at = NOW(), reviewed_at = NOW()
                    WHERE id = %s
                """
                cursor.execute(sql, (new_status, admin_notes, expiry_date, visa_id))
            else:
                sql = """
                    UPDATE visas 
                    SET status = %s, admin_notes = %s, reviewed_at = NOW()
                    WHERE id = %s
                """
                cursor.execute(sql, (new_status, admin_notes, visa_id))
            conn.commit()
            return cursor.rowcount > 0  # True if a row was updated
    except Exception as e:
        conn.rollback()
        print(f"[VISA MODEL ERROR] update_visa_status: {e}")
        return False
    finally:
        conn.close()


def get_all_visas(status_filter=None):
    """
    Admin function: Gets all visa applications.
    Optional status_filter (e.g. 'pending') to filter by status.
    """
    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            if status_filter:
                sql = """
                    SELECT v.*, u.full_name, u.email, u.nationality 
                    FROM visas v 
                    JOIN users u ON v.user_id = u.id 
                    WHERE v.status = %s 
                    ORDER BY v.created_at DESC
                """
                cursor.execute(sql, (status_filter,))
            else:
                sql = """
                    SELECT v.*, u.full_name, u.email, u.nationality 
                    FROM visas v 
                    JOIN users u ON v.user_id = u.id 
                    ORDER BY v.created_at DESC
                """
                cursor.execute(sql)
            return cursor.fetchall()
    finally:
        conn.close()


def save_document(visa_id, user_id, doc_type, original_filename, stored_filename, file_path, file_size, mime_type):
    """Saves document metadata to the documents table after file upload."""
    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            sql = """
                INSERT INTO documents 
                (visa_id, user_id, document_type, original_filename, stored_filename, file_path, file_size, mime_type)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
            """
            cursor.execute(sql, (visa_id, user_id, doc_type, original_filename, stored_filename, file_path, file_size, mime_type))
            conn.commit()
            return cursor.lastrowid
    except Exception as e:
        conn.rollback()
        print(f"[VISA MODEL ERROR] save_document: {e}")
        return None
    finally:
        conn.close()


def get_documents_by_visa(visa_id):
    """Gets all uploaded documents for a specific visa application."""
    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            sql = "SELECT * FROM documents WHERE visa_id = %s"
            cursor.execute(sql, (visa_id,))
            return cursor.fetchall()
    finally:
        conn.close()
