# controllers/visa_controller.py
# ============================================================
# Visa Controller
# Handles all visa application business logic
# ============================================================

from models.visa_model import (
    create_visa_application, get_visas_by_user, get_visa_by_id,
    get_visa_by_application_number, update_visa_status,
    get_all_visas, save_document, get_documents_by_visa
)
from services.ai_fraud_detection import analyze_application
from services.notification_service import send_notification
from utils.file_upload import save_uploaded_file
import os


def apply_for_visa(user_id, data):
    """
    Processes a new visa application.
    Runs fraud detection before saving.
    Returns (response_dict, http_status_code)
    """
    # Validate required fields
    required = ['visa_type', 'destination_country', 'travel_date', 'return_date', 'duration_of_stay']
    for field in required:
        if not data.get(field):
            return {'success': False, 'message': f'Missing required field: {field}'}, 400

    visa_type = data['visa_type']
    destination_country = data['destination_country']
    travel_date = data['travel_date']
    return_date = data['return_date']
    duration_of_stay = data['duration_of_stay']
    purpose = data.get('purpose_of_visit', '')

    # --- Run AI Fraud Detection ---
    fraud_result = analyze_application(data)
    fraud_score = fraud_result['score']
    fraud_flagged = fraud_result['flagged']

    # Create visa application in DB
    visa_id, app_number = create_visa_application(
        user_id=user_id,
        visa_type=visa_type,
        purpose=purpose,
        destination_country=destination_country,
        travel_date=travel_date,
        return_date=return_date,
        duration_of_stay=duration_of_stay,
        application_type='new',
        fraud_score=fraud_score,
        fraud_flagged=fraud_flagged
    )

    if not visa_id:
        return {'success': False, 'message': 'Failed to submit application. Please try again.'}, 500

    # Send confirmation notification
    send_notification(
        user_id=user_id,
        visa_id=visa_id,
        notification_type='application_received',
        message=f'Your visa application {app_number} has been received and is under review.'
    )

    return {
        'success': True,
        'message': 'Visa application submitted successfully!',
        'application_number': app_number,
        'visa_id': visa_id,
        'fraud_flagged': fraud_flagged  # Informational only
    }, 201


def get_visa_status(user_id, application_number=None):
    """
    Gets visa status for a user.
    If application_number is given, fetches that specific visa.
    Otherwise returns all visas for the user.
    """
    if application_number:
        visa = get_visa_by_application_number(application_number)
        if not visa:
            return {'success': False, 'message': 'Application not found'}, 404
        # Security check: make sure this visa belongs to this user
        if visa['user_id'] != int(user_id):
            return {'success': False, 'message': 'Unauthorized access'}, 403

        # Also get documents for this visa
        documents = get_documents_by_visa(visa['id'])
        visa['documents'] = documents

        return {'success': True, 'visa': visa}, 200
    else:
        # Return all visas for this user
        visas = get_visas_by_user(user_id)
        return {'success': True, 'visas': visas, 'total': len(visas)}, 200


def renew_visa(user_id, data):
    """
    Processes a visa renewal request.
    Links the new application to the previous one.
    """
    previous_visa_id = data.get('previous_visa_id')
    if not previous_visa_id:
        return {'success': False, 'message': 'Previous visa ID is required for renewal'}, 400

    # Verify the previous visa belongs to this user
    prev_visa = get_visa_by_id(previous_visa_id)
    if not prev_visa:
        return {'success': False, 'message': 'Previous visa not found'}, 404
    if prev_visa['user_id'] != int(user_id):
        return {'success': False, 'message': 'Unauthorized'}, 403

    # Validate renewal fields
    required = ['visa_type', 'destination_country', 'travel_date', 'return_date', 'duration_of_stay']
    for field in required:
        if not data.get(field):
            return {'success': False, 'message': f'Missing field: {field}'}, 400

    # Fraud detection for renewal
    fraud_result = analyze_application(data)

    visa_id, app_number = create_visa_application(
        user_id=user_id,
        visa_type=data['visa_type'],
        purpose=data.get('purpose_of_visit', 'Renewal'),
        destination_country=data['destination_country'],
        travel_date=data['travel_date'],
        return_date=data['return_date'],
        duration_of_stay=data['duration_of_stay'],
        application_type='renewal',
        previous_visa_id=previous_visa_id,
        fraud_score=fraud_result['score'],
        fraud_flagged=fraud_result['flagged']
    )

    if not visa_id:
        return {'success': False, 'message': 'Renewal submission failed'}, 500

    send_notification(
        user_id=user_id,
        visa_id=visa_id,
        notification_type='application_received',
        message=f'Your visa renewal application {app_number} has been submitted successfully.'
    )

    return {
        'success': True,
        'message': 'Visa renewal application submitted!',
        'application_number': app_number,
        'visa_id': visa_id
    }, 201


def upload_document(user_id, visa_id, file, doc_type):
    """
    Handles document upload for a visa application.
    """
    # Security: verify the visa belongs to this user
    visa = get_visa_by_id(visa_id)
    if not visa:
        return {'success': False, 'message': 'Visa application not found'}, 404
    if visa['user_id'] != int(user_id):
        return {'success': False, 'message': 'Unauthorized'}, 403

    # Save file to disk
    result = save_uploaded_file(file, visa_id)
    if not result['success']:
        return {'success': False, 'message': result['message']}, 400

    # Save file metadata to database
    doc_id = save_document(
        visa_id=visa_id,
        user_id=user_id,
        doc_type=doc_type,
        original_filename=result['original_filename'],
        stored_filename=result['stored_filename'],
        file_path=result['file_path'],
        file_size=result['file_size'],
        mime_type=result['mime_type']
    )

    if not doc_id:
        return {'success': False, 'message': 'Failed to save document record'}, 500

    return {
        'success': True,
        'message': 'Document uploaded successfully',
        'document_id': doc_id,
        'filename': result['original_filename']
    }, 201


def admin_update_visa(visa_id, data):
    """
    Admin function: Approves or rejects a visa application.
    """
    new_status = data.get('status')
    admin_notes = data.get('admin_notes', '')
    expiry_date = data.get('expiry_date')  # Required when approving

    allowed_statuses = ['approved', 'rejected', 'under_review']
    if new_status not in allowed_statuses:
        return {'success': False, 'message': f'Invalid status. Must be one of: {allowed_statuses}'}, 400

    if new_status == 'approved' and not expiry_date:
        return {'success': False, 'message': 'Expiry date is required when approving a visa'}, 400

    # Get the visa to find the user_id for notifications
    visa = get_visa_by_id(visa_id)
    if not visa:
        return {'success': False, 'message': 'Visa not found'}, 404

    success = update_visa_status(visa_id, new_status, admin_notes, expiry_date)
    if not success:
        return {'success': False, 'message': 'Update failed'}, 500

    # Notify the applicant of the decision
    notif_type = 'approval' if new_status == 'approved' else 'status_update'
    msg = f'Your visa application has been {new_status}. Notes: {admin_notes}' if admin_notes else f'Your visa application has been {new_status}.'
    send_notification(user_id=visa['user_id'], visa_id=visa_id, notification_type=notif_type, message=msg)

    return {'success': True, 'message': f'Visa status updated to {new_status}'}, 200


def admin_get_all_visas(status_filter=None):
    """Admin function: Gets all visa applications, optionally filtered by status."""
    visas = get_all_visas(status_filter)
    return {'success': True, 'visas': visas, 'total': len(visas)}, 200
