# controllers/auth_controller.py
# ============================================================
# Authentication Controller
# Handles user registration and login logic
# ============================================================

from models.user_model import create_user, find_user_by_email, verify_password
from flask_jwt_extended import create_access_token
from datetime import timedelta
import re


def register_user(data):
    """
    Handles user registration.
    Validates input, checks for duplicate email, and creates the user.
    Returns (response_dict, http_status_code)
    """
    # --- Input Validation ---
    required_fields = ['full_name', 'email', 'password']
    for field in required_fields:
        if not data.get(field):
            return {'success': False, 'message': f'Missing required field: {field}'}, 400

    full_name = data['full_name'].strip()
    email = data['email'].strip().lower()
    password = data['password']
    phone = data.get('phone', '').strip()
    nationality = data.get('nationality', '').strip()
    date_of_birth = data.get('date_of_birth')  # Expected format: YYYY-MM-DD

    # Validate email format
    email_pattern = r'^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$'
    if not re.match(email_pattern, email):
        return {'success': False, 'message': 'Invalid email address format'}, 400

    # Validate password length
    if len(password) < 6:
        return {'success': False, 'message': 'Password must be at least 6 characters long'}, 400

    # Check if email is already registered
    existing_user = find_user_by_email(email)
    if existing_user:
        return {'success': False, 'message': 'An account with this email already exists'}, 409

    # Create the user in the database
    user_id = create_user(full_name, email, password, phone, nationality, date_of_birth)
    if not user_id:
        return {'success': False, 'message': 'Registration failed. Please try again.'}, 500

    return {
        'success': True,
        'message': 'Registration successful! You can now log in.',
        'user_id': user_id
    }, 201


def login_user(data):
    """
    Handles user login.
    Validates credentials and returns a JWT token on success.
    Returns (response_dict, http_status_code)
    """
    email = data.get('email', '').strip().lower()
    password = data.get('password', '')

    if not email or not password:
        return {'success': False, 'message': 'Email and password are required'}, 400

    # Look up user in database
    user = find_user_by_email(email)
    if not user:
        return {'success': False, 'message': 'Invalid email or password'}, 401

    # Check password
    if not verify_password(password, user['password_hash']):
        return {'success': False, 'message': 'Invalid email or password'}, 401

    # Create JWT token - expires in 24 hours
    # We store user_id and role in the token payload
    token_identity = str(user['id'])
    additional_claims = {
        'role': user['role'],
        'full_name': user['full_name'],
        'email': user['email']
    }
    access_token = create_access_token(
        identity=token_identity,
        additional_claims=additional_claims,
        expires_delta=timedelta(hours=24)
    )

    return {
        'success': True,
        'message': 'Login successful',
        'access_token': access_token,
        'user': {
            'id': user['id'],
            'full_name': user['full_name'],
            'email': user['email'],
            'role': user['role']
        }
    }, 200
