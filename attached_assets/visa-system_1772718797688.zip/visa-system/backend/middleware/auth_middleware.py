# middleware/auth_middleware.py
# ============================================================
# Authentication Middleware
# Decorators to protect routes that require login or admin role
# ============================================================

from functools import wraps
from flask import jsonify
from flask_jwt_extended import verify_jwt_in_request, get_jwt, get_jwt_identity


def login_required(f):
    """
    Decorator that protects a route - user must be logged in.
    Use like: @login_required above your route function.
    If the JWT token is missing or invalid, returns 401 Unauthorized.
    """
    @wraps(f)
    def decorated(*args, **kwargs):
        try:
            # This will raise an exception if no valid token is present
            verify_jwt_in_request()
        except Exception as e:
            return jsonify({'success': False, 'message': 'Authentication required. Please log in.'}), 401
        return f(*args, **kwargs)
    return decorated


def admin_required(f):
    """
    Decorator that protects admin-only routes.
    User must be logged in AND have role='admin'.
    """
    @wraps(f)
    def decorated(*args, **kwargs):
        try:
            verify_jwt_in_request()
        except Exception:
            return jsonify({'success': False, 'message': 'Authentication required'}), 401

        # Check the role stored in the JWT token
        claims = get_jwt()
        if claims.get('role') != 'admin':
            return jsonify({'success': False, 'message': 'Admin access required'}), 403

        return f(*args, **kwargs)
    return decorated
