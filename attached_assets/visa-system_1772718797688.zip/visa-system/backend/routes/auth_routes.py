# routes/auth_routes.py
# ============================================================
# Authentication Routes
# POST /register - Create a new account
# POST /login    - Login and receive JWT token
# GET  /me       - Get current user profile (requires login)
# ============================================================

from flask import Blueprint, request, jsonify
from controllers.auth_controller import register_user, login_user
from middleware.auth_middleware import login_required
from flask_jwt_extended import get_jwt_identity
from models.user_model import find_user_by_id

# Create a Blueprint - a way to organize routes in Flask
auth_bp = Blueprint('auth', __name__)


@auth_bp.route('/register', methods=['POST'])
def register():
    """
    POST /register
    Register a new user account.
    
    Expected JSON body:
    {
        "full_name": "John Doe",
        "email": "john@example.com",
        "password": "securepassword",
        "phone": "+1234567890",       (optional)
        "nationality": "American",    (optional)
        "date_of_birth": "1990-01-15" (optional)
    }
    """
    data = request.get_json()
    if not data:
        return jsonify({'success': False, 'message': 'Request body must be JSON'}), 400
    
    response, status_code = register_user(data)
    return jsonify(response), status_code


@auth_bp.route('/login', methods=['POST'])
def login():
    """
    POST /login
    Authenticate a user and return a JWT token.
    
    Expected JSON body:
    {
        "email": "john@example.com",
        "password": "securepassword"
    }
    
    Returns:
        access_token: Use this in the Authorization header as "Bearer <token>"
    """
    data = request.get_json()
    if not data:
        return jsonify({'success': False, 'message': 'Request body must be JSON'}), 400
    
    response, status_code = login_user(data)
    return jsonify(response), status_code


@auth_bp.route('/me', methods=['GET'])
@login_required
def get_profile():
    """
    GET /me
    Returns the currently logged-in user's profile.
    Requires: Authorization: Bearer <jwt_token>
    """
    user_id = get_jwt_identity()
    user = find_user_by_id(user_id)
    
    if not user:
        return jsonify({'success': False, 'message': 'User not found'}), 404
    
    return jsonify({'success': True, 'user': user}), 200
