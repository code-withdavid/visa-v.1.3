# routes/visa_routes.py
# ============================================================
# Visa Application Routes
# POST /apply-visa       - Submit new visa application
# GET  /visa-status      - Get visa status
# POST /renew-visa       - Submit renewal request
# POST /upload-document  - Upload a document
# GET  /admin/visas      - Admin: Get all applications
# PUT  /admin/visa/<id>  - Admin: Approve/reject application
# ============================================================

from flask import Blueprint, request, jsonify
from controllers.visa_controller import (
    apply_for_visa, get_visa_status, renew_visa,
    upload_document, admin_update_visa, admin_get_all_visas
)
from middleware.auth_middleware import login_required, admin_required
from flask_jwt_extended import get_jwt_identity

# Create a Blueprint for visa-related routes
visa_bp = Blueprint('visa', __name__)


@visa_bp.route('/apply-visa', methods=['POST'])
@login_required
def apply_visa():
    """
    POST /apply-visa
    Submit a new visa application.
    Requires login.
    
    Expected JSON body:
    {
        "visa_type": "tourist",
        "destination_country": "France",
        "travel_date": "2024-06-01",
        "return_date": "2024-06-15",
        "duration_of_stay": 14,
        "purpose_of_visit": "Tourism and sightseeing"
    }
    """
    user_id = get_jwt_identity()
    data = request.get_json()
    
    if not data:
        return jsonify({'success': False, 'message': 'Request body must be JSON'}), 400
    
    response, status_code = apply_for_visa(user_id, data)
    return jsonify(response), status_code


@visa_bp.route('/visa-status', methods=['GET'])
@login_required
def visa_status():
    """
    GET /visa-status
    Get all visas for the current user.
    
    Optional query parameter:
    ?application_number=VIS-2024-ABCD1234  (for a specific visa)
    
    Requires login.
    """
    user_id = get_jwt_identity()
    application_number = request.args.get('application_number')
    
    response, status_code = get_visa_status(user_id, application_number)
    return jsonify(response), status_code


@visa_bp.route('/renew-visa', methods=['POST'])
@login_required
def renew_visa_route():
    """
    POST /renew-visa
    Submit a visa renewal application.
    Requires login.
    
    Expected JSON body:
    {
        "previous_visa_id": 5,
        "visa_type": "tourist",
        "destination_country": "France",
        "travel_date": "2024-12-01",
        "return_date": "2024-12-15",
        "duration_of_stay": 14,
        "purpose_of_visit": "Extended tourism visit"
    }
    """
    user_id = get_jwt_identity()
    data = request.get_json()
    
    if not data:
        return jsonify({'success': False, 'message': 'Request body must be JSON'}), 400
    
    response, status_code = renew_visa(user_id, data)
    return jsonify(response), status_code


@visa_bp.route('/upload-document', methods=['POST'])
@login_required
def upload_doc():
    """
    POST /upload-document
    Upload a document for a visa application.
    Requires login. Uses multipart/form-data.
    
    Form fields:
    - file: The file to upload (PDF, JPG, JPEG, PNG)
    - visa_id: The visa application ID
    - document_type: One of: passport, photo, bank_statement, invitation_letter, travel_insurance, other
    """
    user_id = get_jwt_identity()
    
    # Get file from multipart form data
    if 'file' not in request.files:
        return jsonify({'success': False, 'message': 'No file in request. Use multipart/form-data'}), 400
    
    file = request.files['file']
    visa_id = request.form.get('visa_id')
    doc_type = request.form.get('document_type', 'other')
    
    if not visa_id:
        return jsonify({'success': False, 'message': 'visa_id is required'}), 400
    
    try:
        visa_id = int(visa_id)
    except ValueError:
        return jsonify({'success': False, 'message': 'visa_id must be a number'}), 400
    
    response, status_code = upload_document(user_id, visa_id, file, doc_type)
    return jsonify(response), status_code


# ---- ADMIN ROUTES ----

@visa_bp.route('/admin/visas', methods=['GET'])
@admin_required
def admin_list_visas():
    """
    GET /admin/visas
    Admin only: Get all visa applications.
    
    Optional query parameter:
    ?status=pending  (filter by status: pending, approved, rejected, etc.)
    """
    status_filter = request.args.get('status')
    response, status_code = admin_get_all_visas(status_filter)
    return jsonify(response), status_code


@visa_bp.route('/admin/visa/<int:visa_id>', methods=['PUT'])
@admin_required
def admin_update_visa_route(visa_id):
    """
    PUT /admin/visa/<visa_id>
    Admin only: Approve or reject a visa application.
    
    Expected JSON body:
    {
        "status": "approved",           # or "rejected" or "under_review"
        "admin_notes": "All good!",      # optional
        "expiry_date": "2025-06-01"      # required if status is "approved"
    }
    """
    data = request.get_json()
    if not data:
        return jsonify({'success': False, 'message': 'Request body must be JSON'}), 400
    
    response, status_code = admin_update_visa(visa_id, data)
    return jsonify(response), status_code
