-- ============================================================
-- Online Visa Granted and Renewal Information System
-- Database Schema - MySQL
-- ============================================================

CREATE DATABASE IF NOT EXISTS visa_system;
USE visa_system;

-- ============================================================
-- USERS TABLE
-- Stores all registered users (applicants and admins)
-- ============================================================
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(150) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    phone VARCHAR(20),
    nationality VARCHAR(100),
    date_of_birth DATE,
    role ENUM('applicant', 'admin') DEFAULT 'applicant',
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- ============================================================
-- VISAS TABLE
-- Stores all visa applications and renewals
-- ============================================================
CREATE TABLE IF NOT EXISTS visas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    application_number VARCHAR(20) NOT NULL UNIQUE,
    visa_type ENUM('tourist', 'student', 'work', 'business', 'transit', 'medical') NOT NULL,
    purpose_of_visit TEXT,
    destination_country VARCHAR(100) NOT NULL,
    travel_date DATE,
    return_date DATE,
    duration_of_stay INT,                          -- number of days
    status ENUM('pending', 'under_review', 'approved', 'rejected', 'expired', 'renewal_pending') DEFAULT 'pending',
    application_type ENUM('new', 'renewal') DEFAULT 'new',
    previous_visa_id INT DEFAULT NULL,             -- for renewals, reference previous visa
    admin_notes TEXT,
    fraud_score FLOAT DEFAULT 0.0,                 -- AI fraud detection score (0-1)
    fraud_flagged BOOLEAN DEFAULT FALSE,
    submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    reviewed_at TIMESTAMP NULL,
    approved_at TIMESTAMP NULL,
    expiry_date DATE NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (previous_visa_id) REFERENCES visas(id) ON DELETE SET NULL
);

-- ============================================================
-- DOCUMENTS TABLE
-- Stores uploaded documents for each visa application
-- ============================================================
CREATE TABLE IF NOT EXISTS documents (
    id INT AUTO_INCREMENT PRIMARY KEY,
    visa_id INT NOT NULL,
    user_id INT NOT NULL,
    document_type ENUM('passport', 'photo', 'bank_statement', 'invitation_letter', 'travel_insurance', 'other') NOT NULL,
    original_filename VARCHAR(255) NOT NULL,
    stored_filename VARCHAR(255) NOT NULL,         -- UUID-renamed file on server
    file_path VARCHAR(500) NOT NULL,
    file_size INT,                                 -- size in bytes
    mime_type VARCHAR(100),
    is_verified BOOLEAN DEFAULT FALSE,
    uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (visa_id) REFERENCES visas(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ============================================================
-- NOTIFICATIONS TABLE
-- Stores email/system notifications sent to users
-- ============================================================
CREATE TABLE IF NOT EXISTS notifications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    visa_id INT,
    notification_type ENUM('application_received', 'status_update', 'approval', 'rejection', 'renewal_reminder', 'expiry_warning') NOT NULL,
    subject VARCHAR(255),
    message TEXT,
    is_read BOOLEAN DEFAULT FALSE,
    sent_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (visa_id) REFERENCES visas(id) ON DELETE SET NULL
);

-- ============================================================
-- SAMPLE DATA - Admin User
-- Password: admin123 (bcrypt hashed - update via app)
-- ============================================================
INSERT INTO users (full_name, email, password_hash, role) VALUES
('System Admin', 'admin@visasystem.com', '$2b$12$placeholder_hash_replace_on_first_run', 'admin');

-- ============================================================
-- INDEXES for better query performance
-- ============================================================
CREATE INDEX idx_visas_user_id ON visas(user_id);
CREATE INDEX idx_visas_status ON visas(status);
CREATE INDEX idx_visas_application_number ON visas(application_number);
CREATE INDEX idx_documents_visa_id ON documents(visa_id);
CREATE INDEX idx_notifications_user_id ON notifications(user_id);
